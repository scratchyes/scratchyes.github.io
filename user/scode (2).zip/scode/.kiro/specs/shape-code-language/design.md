# Shape Code 语言系统设计文档

## 概述

Shape Code 系统是一个基于 Python 的 3D 建模工具，通过三层架构实现从自然语言到 3D 模型的转换：

1. **自然语言层**：用户使用自然语言描述 3D 形状
2. **Shape Code 层**：AI 生成的中间表示语言，人类可读可编辑
3. **3D 模型层**：标准格式的 3D 文件（STL、OBJ）

系统采用模块化设计，核心组件包括自然语言处理器、Shape Code 解析器、几何引擎、编译器和 GUI 界面。

## 架构

### 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                         GUI 层 (PyQt6)                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ 自然语言输入 │  │ Shape Code   │  │  3D 预览窗口     │  │
│  │    面板      │  │   编辑器     │  │  (PyVista)       │  │
│  └──────────────┘  └──────────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      应用逻辑层                              │
│  ┌──────────────────┐         ┌──────────────────────┐     │
│  │  自然语言处理器  │         │   文件管理器         │     │
│  │  (NL Processor)  │         │  (File Manager)      │     │
│  │  - OpenAI API    │         │  - 加载/保存         │     │
│  │  - 提示工程      │         │  - 示例库            │     │
│  └──────────────────┘         └──────────────────────┘     │
│           │                              │                   │
│           ▼                              ▼                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │            Shape Code 解析器 (Parser)                │  │
│  │            - 词法分析 (Lexer)                        │  │
│  │            - 语法分析 (Parser)                       │  │
│  │            - AST 构建                                │  │
│  └──────────────────────────────────────────────────────┘  │
│                            │                                 │
│                            ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              几何引擎 (Geometry Engine)              │  │
│  │              - 基本形状生成                          │  │
│  │              - 变换操作                              │  │
│  │              - 布尔运算 (使用 trimesh)               │  │
│  └──────────────────────────────────────────────────────┘  │
│                            │                                 │
│                            ▼                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              编译器 (Compiler)                       │  │
│  │              - STL 导出                              │  │
│  │              - OBJ 导出                              │  │
│  │              - 网格优化                              │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 技术栈

- **GUI 框架**: PyQt6 - 跨平台的现代 GUI 框架
- **3D 渲染**: PyVista - 基于 VTK 的 3D 可视化库
- **几何处理**: trimesh - Python 3D 网格处理库
- **自然语言处理**: OpenAI API (GPT-4) - 用于自然语言到 Shape Code 的转换
- **解析器**: PLY (Python Lex-Yacc) - 用于构建 Shape Code 解析器
- **配置管理**: JSON - 存储用户偏好设置

## 组件和接口

### 1. Shape Code 语言定义

Shape Code 采用声明式语法，类似于 Python 和 OpenSCAD 的混合风格。

#### 语法示例

```shapecode
# 基本形状定义
cube = Cube(size=[10, 10, 10])
sphere = Sphere(radius=5)
cylinder = Cylinder(radius=3, height=10)
cone = Cone(radius=4, height=8)

# 变换操作
translated_cube = cube.translate([5, 0, 0])
rotated_sphere = sphere.rotate([0, 0, 45])
scaled_cylinder = cylinder.scale([1, 1, 2])

# 布尔运算
union_shape = cube + sphere
difference_shape = cube - sphere
intersection_shape = cube & sphere

# 组合操作
complex_shape = (Cube(size=[20, 20, 20]) - Sphere(radius=12)).translate([0, 0, 10])

# 导出
export(complex_shape, "output.stl")
```

#### 语法规则（BNF 表示）

```bnf
<program> ::= <statement>*

<statement> ::= <assignment> | <export>

<assignment> ::= <identifier> "=" <expression>

<expression> ::= <primitive> | <transform> | <boolean_op> | <identifier>

<primitive> ::= "Cube" "(" <params> ")"
              | "Sphere" "(" <params> ")"
              | "Cylinder" "(" <params> ")"
              | "Cone" "(" <params> ")"

<transform> ::= <expression> "." "translate" "(" <vector> ")"
              | <expression> "." "rotate" "(" <vector> ")"
              | <expression> "." "scale" "(" <vector> ")"

<boolean_op> ::= <expression> "+" <expression>  # 并集
               | <expression> "-" <expression>  # 差集
               | <expression> "&" <expression>  # 交集

<export> ::= "export" "(" <expression> "," <string> ")"

<params> ::= <param> ("," <param>)*
<param> ::= <identifier> "=" <value>
<value> ::= <number> | <vector> | <string>
<vector> ::= "[" <number> ("," <number>)* "]"
```

### 2. 自然语言处理器 (NLProcessor)

#### 接口定义

```python
class NLProcessor:
    """自然语言到 Shape Code 的转换器"""
    
    def __init__(self, api_key: str):
        """初始化 OpenAI 客户端"""
        pass
    
    def process(self, natural_language: str) -> Result[str, str]:
        """
        将自然语言转换为 Shape Code
        
        Args:
            natural_language: 用户的自然语言描述
            
        Returns:
            Result[str, str]: 成功返回 Shape Code，失败返回错误信息
        """
        pass
    
    def _build_prompt(self, user_input: str) -> str:
        """构建发送给 AI 的提示"""
        pass
```

#### 提示工程策略

系统使用精心设计的提示模板，包含：
- Shape Code 语法规则和示例
- 常见形状的转换模式
- 空间关系的表达方式
- Few-shot 学习示例

### 3. Shape Code 解析器 (Parser)

#### 接口定义

```python
class Token:
    """词法单元"""
    type: str
    value: Any
    line: int
    column: int

class ASTNode:
    """抽象语法树节点基类"""
    pass

class Primitive(ASTNode):
    """基本形状节点"""
    shape_type: str  # 'cube', 'sphere', 'cylinder', 'cone'
    params: Dict[str, Any]

class Transform(ASTNode):
    """变换操作节点"""
    target: ASTNode
    transform_type: str  # 'translate', 'rotate', 'scale'
    params: List[float]

class BooleanOp(ASTNode):
    """布尔运算节点"""
    left: ASTNode
    right: ASTNode
    operation: str  # 'union', 'difference', 'intersection'

class Assignment(ASTNode):
    """赋值语句节点"""
    identifier: str
    expression: ASTNode

class Lexer:
    """词法分析器"""
    
    def tokenize(self, code: str) -> List[Token]:
        """将 Shape Code 转换为 token 流"""
        pass

class Parser:
    """语法分析器"""
    
    def parse(self, tokens: List[Token]) -> Result[List[ASTNode], ParseError]:
        """将 token 流解析为 AST"""
        pass
    
    def validate(self, ast: List[ASTNode]) -> Result[None, ValidationError]:
        """验证 AST 的语义正确性"""
        pass
```

### 4. 几何引擎 (GeometryEngine)

#### 接口定义

```python
class GeometryEngine:
    """3D 几何操作引擎"""
    
    def create_cube(self, size: List[float]) -> trimesh.Trimesh:
        """创建立方体"""
        pass
    
    def create_sphere(self, radius: float, subdivisions: int = 3) -> trimesh.Trimesh:
        """创建球体"""
        pass
    
    def create_cylinder(self, radius: float, height: float, segments: int = 32) -> trimesh.Trimesh:
        """创建圆柱体"""
        pass
    
    def create_cone(self, radius: float, height: float, segments: int = 32) -> trimesh.Trimesh:
        """创建圆锥体"""
        pass
    
    def translate(self, mesh: trimesh.Trimesh, vector: List[float]) -> trimesh.Trimesh:
        """平移操作"""
        pass
    
    def rotate(self, mesh: trimesh.Trimesh, angles: List[float]) -> trimesh.Trimesh:
        """旋转操作（欧拉角，度数）"""
        pass
    
    def scale(self, mesh: trimesh.Trimesh, factors: List[float]) -> trimesh.Trimesh:
        """缩放操作"""
        pass
    
    def union(self, mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
        """并集运算"""
        pass
    
    def difference(self, mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
        """差集运算"""
        pass
    
    def intersection(self, mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
        """交集运算"""
        pass
```

### 5. 编译器 (Compiler)

#### 接口定义

```python
class CompilerOptions:
    """编译选项"""
    resolution: str  # 'low', 'medium', 'high'
    optimize: bool
    
class CompilationResult:
    """编译结果"""
    mesh: trimesh.Trimesh
    stats: Dict[str, Any]  # 面数、顶点数、文件大小等

class Compiler:
    """Shape Code 编译器"""
    
    def compile(self, ast: List[ASTNode], options: CompilerOptions) -> Result[CompilationResult, CompileError]:
        """
        将 AST 编译为 3D 网格
        
        Args:
            ast: 抽象语法树
            options: 编译选项
            
        Returns:
            Result[CompilationResult, CompileError]: 编译结果或错误
        """
        pass
    
    def export_stl(self, mesh: trimesh.Trimesh, filepath: str) -> Result[None, IOError]:
        """导出为 STL 格式"""
        pass
    
    def export_obj(self, mesh: trimesh.Trimesh, filepath: str) -> Result[None, IOError]:
        """导出为 OBJ 格式"""
        pass
    
    def optimize_mesh(self, mesh: trimesh.Trimesh) -> trimesh.Trimesh:
        """优化网格（合并重复顶点、移除退化面等）"""
        pass
```

### 6. GUI 应用 (MainWindow)

#### 接口定义

```python
class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        """初始化 UI 组件"""
        pass
    
    # UI 组件
    nl_input: QTextEdit  # 自然语言输入框
    code_editor: CodeEditor  # Shape Code 编辑器
    preview_widget: PreviewWidget  # 3D 预览窗口
    status_bar: QStatusBar  # 状态栏
    
    # 槽函数
    def on_generate_clicked(self):
        """处理"生成"按钮点击"""
        pass
    
    def on_compile_clicked(self):
        """处理"编译"按钮点击"""
        pass
    
    def on_export_clicked(self):
        """处理"导出"按钮点击"""
        pass
    
    def on_file_open(self):
        """打开文件"""
        pass
    
    def on_file_save(self):
        """保存文件"""
        pass
    
    def on_load_example(self, example_name: str):
        """加载示例"""
        pass

class CodeEditor(QPlainTextEdit):
    """Shape Code 编辑器（带语法高亮）"""
    
    def __init__(self):
        self.highlighter = ShapeCodeHighlighter(self.document())
        self.completer = ShapeCodeCompleter(self)
    
class PreviewWidget(QWidget):
    """3D 预览窗口"""
    
    def __init__(self):
        self.plotter = pyvista.QtInteractor(self)
    
    def update_mesh(self, mesh: trimesh.Trimesh):
        """更新显示的 3D 模型"""
        pass
    
    def reset_camera(self):
        """重置相机视角"""
        pass
```

### 7. 文件管理器 (FileManager)

#### 接口定义

```python
class FileManager:
    """文件和配置管理"""
    
    def save_shapecode(self, code: str, filepath: str) -> Result[None, IOError]:
        """保存 Shape Code 文件"""
        pass
    
    def load_shapecode(self, filepath: str) -> Result[str, IOError]:
        """加载 Shape Code 文件"""
        pass
    
    def load_example(self, example_name: str) -> str:
        """从内置示例库加载"""
        pass
    
    def list_examples(self) -> List[str]:
        """列出所有示例"""
        pass
    
    def save_preferences(self, prefs: Dict[str, Any]):
        """保存用户偏好设置"""
        pass
    
    def load_preferences(self) -> Dict[str, Any]:
        """加载用户偏好设置"""
        pass
    
    def add_recent_file(self, filepath: str):
        """添加到最近文件列表"""
        pass
    
    def get_recent_files(self) -> List[str]:
        """获取最近文件列表"""
        pass
```

## 数据模型

### Shape Code 文件格式

```
.shapecode 文件（纯文本，UTF-8 编码）
```

### 配置文件格式

```json
{
  "preferences": {
    "window": {
      "width": 1200,
      "height": 800,
      "maximized": false
    },
    "editor": {
      "font_size": 12,
      "theme": "light"
    },
    "export": {
      "default_format": "stl",
      "default_resolution": "medium"
    },
    "recent_files": [
      "/path/to/file1.shapecode",
      "/path/to/file2.shapecode"
    ]
  }
}
```

### 示例库结构

```
examples/
├── basic/
│   ├── cube.shapecode
│   ├── sphere.shapecode
│   ├── cylinder.shapecode
│   └── cone.shapecode
├── transforms/
│   ├── translated.shapecode
│   ├── rotated.shapecode
│   └── scaled.shapecode
├── boolean/
│   ├── union.shapecode
│   ├── difference.shapecode
│   └── intersection.shapecode
└── complex/
    ├── gear.shapecode
    ├── house.shapecode
    └── vase.shapecode
```

## 错误处理

### 错误类型层次

```python
class ShapeCodeError(Exception):
    """基础错误类"""
    message: str
    line: Optional[int]
    column: Optional[int]

class ParseError(ShapeCodeError):
    """解析错误"""
    pass

class ValidationError(ShapeCodeError):
    """验证错误"""
    pass

class CompileError(ShapeCodeError):
    """编译错误"""
    pass

class GeometryError(ShapeCodeError):
    """几何操作错误"""
    pass

class NLProcessError(ShapeCodeError):
    """自然语言处理错误"""
    pass
```

### 错误处理策略

1. **解析阶段**：捕获语法错误，提供行号和列号
2. **验证阶段**：检查语义错误（如未定义的变量、类型不匹配）
3. **编译阶段**：处理几何操作失败（如无效的布尔运算）
4. **用户界面**：在状态栏和对话框中显示友好的错误信息

### 错误信息示例

```
解析错误：第 5 行，第 12 列
  unexpected token '}'
  期望: 表达式

建议：检查括号是否匹配
```

## 测试策略

### 单元测试

- **Lexer 测试**：验证词法分析的正确性
- **Parser 测试**：测试各种语法结构的解析
- **GeometryEngine 测试**：验证几何操作的数学正确性
- **Compiler 测试**：测试 AST 到网格的转换

### 集成测试

- **端到端测试**：从自然语言输入到 3D 文件导出的完整流程
- **GUI 测试**：使用 pytest-qt 测试用户界面交互

### 性能测试

- **编译性能**：测试不同复杂度模型的编译时间
- **渲染性能**：测试不同面数模型的渲染帧率
- **内存使用**：监控大型模型的内存占用

### 测试数据

- 创建一套标准测试用例，包括：
  - 简单形状（单个基本体）
  - 中等复杂度（5-10 个形状组合）
  - 复杂模型（50+ 个形状）
  - 边界情况（极小/极大尺寸、深度嵌套）

## 性能考虑

### 优化策略

1. **延迟编译**：只在用户请求预览或导出时才编译
2. **缓存机制**：缓存已编译的子表达式，避免重复计算
3. **多线程**：在后台线程执行编译和导出操作，保持 UI 响应
4. **网格简化**：对于预览，使用较低分辨率的网格
5. **增量更新**：代码编辑时只重新编译修改的部分

### 性能目标

- 简单模型（<10 个形状）：编译时间 < 1 秒
- 中等模型（10-50 个形状）：编译时间 < 5 秒
- 复杂模型（50-100 个形状）：编译时间 < 15 秒
- 预览渲染：60 FPS（对于 <10K 面的模型）

## 安全性考虑

1. **代码执行隔离**：Shape Code 不支持任意 Python 代码执行
2. **文件系统访问**：限制文件操作在用户指定的目录内
3. **API 密钥管理**：安全存储 OpenAI API 密钥（使用系统密钥链）
4. **输入验证**：严格验证所有用户输入，防止注入攻击

## 扩展性设计

### 插件系统（未来）

预留插件接口，允许：
- 自定义形状类型
- 自定义变换操作
- 自定义导出格式
- 自定义 AI 后端

### 多语言支持

- 界面文本国际化（i18n）
- 支持多种自然语言输入（中文、英文等）

## 部署和分发

### 打包方式

使用 PyInstaller 打包为独立可执行文件：

**Windows**：
- 单文件 .exe（推荐）：所有依赖打包在一个可执行文件中
- 用户无需安装 Python 或任何依赖
- 双击即可运行，无需安装过程
- 使用 `--onefile` 选项打包

**其他平台**：
- macOS: .app 应用包
- Linux: AppImage

### PyInstaller 配置

```python
# shapecode.spec
a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[('examples', 'examples'), ('assets', 'assets')],
    hiddenimports=['pyvistaqt', 'vtkmodules'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=None,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='ShapeCode',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # 无控制台窗口
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='assets/icon.ico'  # 应用图标
)
```

### 依赖管理

开发环境使用 requirements.txt 和 poetry 管理依赖：

```
PyQt6>=6.5.0
pyvista>=0.42.0
trimesh>=4.0.0
numpy>=1.24.0
openai>=1.0.0
ply>=3.11
pyinstaller>=5.13.0
```

### Windows 用户体验

1. **零安装运行**：
   - 下载 ShapeCode.exe
   - 双击运行，无需安装
   - 首次运行时自动创建配置目录（%APPDATA%/ShapeCode）

2. **可选安装程序**（使用 Inno Setup）：
   - 创建开始菜单快捷方式
   - 注册 .shapecode 文件关联
   - 添加到系统 PATH（可选）
   - 提供卸载功能

3. **便携模式**：
   - 支持从 U 盘运行
   - 配置文件可保存在 exe 同目录下
