# 关于可执行文件的说明

## 当前状态

✅ **配置已完成** - 所有构建配置文件已创建  
⏳ **需要手动构建** - 可执行文件需要你自己构建

## 为什么没有预构建的可执行文件？

1. **文件大小**: 可执行文件通常 50-100 MB，不适合包含在源代码仓库中
2. **平台差异**: 需要为 Windows、Linux、Mac 分别构建
3. **依赖更新**: 当库更新时需要重新构建
4. **Git 最佳实践**: 二进制文件不应提交到 Git

## 如何获得可执行文件？

### 选项 1: 自己构建（推荐）

**最简单的方式 - 使用构建脚本:**

Windows:
```bash
build.bat
```

Linux/Mac:
```bash
chmod +x build.sh
./build.sh
```

构建完成后，可执行文件位于:
- Windows: `dist/ShapeCode.exe`
- Linux/Mac: `dist/ShapeCode`

**详细说明**: 查看 [BUILD_EXECUTABLE.md](BUILD_EXECUTABLE.md)

### 选项 2: 直接运行 Python 代码（无需构建）

如果你已经安装了 Python，可以直接运行:

```bash
# CLI 模式
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl

# GUI 模式（需要 PyQt6）
python main.py
```

这种方式不需要构建可执行文件，更适合开发和测试。

## 构建时间和文件大小

- **构建时间**: 首次构建约 3-5 分钟
- **文件大小**: 约 50-100 MB（取决于平台和依赖）

## 已提供的文件

✅ `shapecode.spec` - PyInstaller 配置文件  
✅ `build.bat` - Windows 自动构建脚本  
✅ `build.sh` - Linux/Mac 自动构建脚本  
✅ `BUILD_EXECUTABLE.md` - 详细构建说明  
✅ `build_instructions.md` - 完整的构建和分发指南

## 快速开始（无需构建）

1. 安装依赖:
```bash
pip install -r requirements.txt
```

2. 运行应用:
```bash
# CLI 模式
python shapecode_cli.py examples/shapecode/basic/cube.shapecode

# GUI 模式
python main.py
```

## 需要帮助？

- 构建问题: 查看 [BUILD_EXECUTABLE.md](BUILD_EXECUTABLE.md)
- 使用问题: 查看 [README.md](README.md)
- 完整文档: 查看 [PROJECT_COMPLETE.md](PROJECT_COMPLETE.md)

## 总结

**你有两个选择:**

1. **构建可执行文件** - 运行 `build.bat` (Windows) 或 `build.sh` (Linux/Mac)
2. **直接运行源代码** - 运行 `python main.py`

两种方式功能完全相同，选择最适合你的方式！
