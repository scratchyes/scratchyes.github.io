"""GUI components for Shape Code."""

__all__ = ['MainWindow']
