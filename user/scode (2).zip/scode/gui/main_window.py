"""Main window for Shape Code application."""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTextEdit, QPlainTextEdit, QPushButton,
    QMenuBar, QMenu, QToolBar, QStatusBar, QLabel,
    QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QAction, QKeySequence
from pathlib import Path

from src.parser import Parser
from src.compiler import Compiler, CompilerOptions
from src.file_manager import FileManager


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self, preferences=None):
        """
        Initialize the main window.
        
        Args:
            preferences: User preferences dictionary
        """
        super().__init__()
        
        self.preferences = preferences or {}
        self.file_manager = FileManager()
        self.parser = Parser()
        self.compiler = None
        self.current_file = None
        self.is_modified = False
        
        self.setup_ui()
        self.restore_window_state()
    
    def setup_ui(self):
        """Set up the user interface."""
        self.setWindowTitle("Shape Code")
        self.setMinimumSize(1000, 700)
        
        # Create central widget with splitter
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)
        
        # Create main splitter (3 panels)
        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(self.main_splitter)
        
        # Left panel: Natural language input
        self.setup_nl_panel()
        
        # Middle panel: Code editor
        self.setup_editor_panel()
        
        # Right panel: 3D preview (placeholder)
        self.setup_preview_panel()
        
        # Set initial splitter sizes
        self.main_splitter.setSizes([300, 400, 400])
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create status bar
        self.create_status_bar()
    
    def setup_nl_panel(self):
        """Set up natural language input panel."""
        nl_widget = QWidget()
        nl_layout = QVBoxLayout(nl_widget)
        
        # Title
        title = QLabel("自然语言输入")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        nl_layout.addWidget(title)
        
        # Text input
        self.nl_input = QTextEdit()
        self.nl_input.setPlaceholderText(
            "用自然语言描述你想要的 3D 模型...\n\n"
            "例如:\n"
            "- 创建一个 10x10x10 的立方体\n"
            "- 制作一个带有球形孔的立方体\n"
            "- 创建一个雪人"
        )
        nl_layout.addWidget(self.nl_input)
        
        # Generate button
        self.generate_btn = QPushButton("生成 Shape Code")
        self.generate_btn.clicked.connect(self.on_generate_clicked)
        nl_layout.addWidget(self.generate_btn)
        
        self.main_splitter.addWidget(nl_widget)
    
    def setup_editor_panel(self):
        """Set up code editor panel."""
        editor_widget = QWidget()
        editor_layout = QVBoxLayout(editor_widget)
        
        # Title
        title = QLabel("Shape Code 编辑器")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        editor_layout.addWidget(title)
        
        # Code editor
        self.code_editor = QPlainTextEdit()
        self.code_editor.setPlaceholderText(
            "# 在这里编写 Shape Code\n"
            "# 或使用左侧的自然语言输入生成代码\n\n"
            "cube = Cube(size=[10, 10, 10])\n"
            "export(cube, \"output.stl\")"
        )
        
        # Set font
        font_family = self.preferences.get('editor', {}).get('font_family', 'Consolas')
        font_size = self.preferences.get('editor', {}).get('font_size', 12)
        font = self.code_editor.font()
        font.setFamily(font_family)
        font.setPointSize(font_size)
        self.code_editor.setFont(font)
        
        # Track modifications
        self.code_editor.textChanged.connect(self.on_text_changed)
        
        editor_layout.addWidget(self.code_editor)
        
        self.main_splitter.addWidget(editor_widget)
    
    def setup_preview_panel(self):
        """Set up 3D preview panel."""
        preview_widget = QWidget()
        preview_layout = QVBoxLayout(preview_widget)
        
        # Title
        title = QLabel("3D 预览")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        preview_layout.addWidget(title)
        
        # Placeholder for 3D view
        self.preview_placeholder = QLabel("3D 预览\n\n点击 '编译' 按钮生成预览")
        self.preview_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_placeholder.setStyleSheet(
            "background-color: #2b2b2b; color: #888; font-size: 14px;"
        )
        preview_layout.addWidget(self.preview_placeholder)
        
        self.main_splitter.addWidget(preview_widget)
    
    def create_menu_bar(self):
        """Create menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("文件(&F)")
        
        new_action = QAction("新建(&N)", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self.on_file_new)
        file_menu.addAction(new_action)
        
        open_action = QAction("打开(&O)...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.on_file_open)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        save_action = QAction("保存(&S)", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self.on_file_save)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("另存为(&A)...", self)
        save_as_action.setShortcut(QKeySequence.StandardKey.SaveAs)
        save_as_action.triggered.connect(self.on_file_save_as)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("退出(&X)", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("编辑(&E)")
        
        undo_action = QAction("撤销(&U)", self)
        undo_action.setShortcut(QKeySequence.StandardKey.Undo)
        undo_action.triggered.connect(self.code_editor.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("重做(&R)", self)
        redo_action.setShortcut(QKeySequence.StandardKey.Redo)
        redo_action.triggered.connect(self.code_editor.redo)
        edit_menu.addAction(redo_action)
        
        # Examples menu
        examples_menu = menubar.addMenu("示例(&X)")
        self.populate_examples_menu(examples_menu)
        
        # Help menu
        help_menu = menubar.addMenu("帮助(&H)")
        
        about_action = QAction("关于(&A)", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def create_toolbar(self):
        """Create toolbar."""
        toolbar = QToolBar()
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # Compile button
        compile_action = QAction("编译", self)
        compile_action.triggered.connect(self.on_compile_clicked)
        toolbar.addAction(compile_action)
        
        toolbar.addSeparator()
        
        # Export button
        export_action = QAction("导出", self)
        export_action.triggered.connect(self.on_export_clicked)
        toolbar.addAction(export_action)
    
    def create_status_bar(self):
        """Create status bar."""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        self.status_label = QLabel("就绪")
        self.status_bar.addWidget(self.status_label)
        
        # Stats label (right side)
        self.stats_label = QLabel("")
        self.status_bar.addPermanentWidget(self.stats_label)
    
    def populate_examples_menu(self, menu):
        """Populate examples menu."""
        examples_result = self.file_manager.list_examples()
        
        if examples_result.is_err():
            return
        
        examples = examples_result.unwrap()
        
        for category, example_list in sorted(examples.items()):
            category_menu = menu.addMenu(category.title())
            
            for example_path in sorted(example_list):
                example_name = Path(example_path).stem
                action = QAction(example_name, self)
                action.setData(example_path)
                action.triggered.connect(lambda checked, path=example_path: self.load_example(path))
                category_menu.addAction(action)
    
    def on_generate_clicked(self):
        """Handle generate button click."""
        nl_text = self.nl_input.toPlainText().strip()
        
        if not nl_text:
            QMessageBox.warning(self, "警告", "请输入自然语言描述")
            return
        
        self.status_label.setText("正在生成 Shape Code...")
        self.generate_btn.setEnabled(False)
        
        # Import here to avoid dependency issues
        try:
            from src.nl_processor import NLProcessor
            
            processor = NLProcessor()
            result = processor.process(nl_text)
            
            if result.is_ok():
                shape_code = result.unwrap()
                self.code_editor.setPlainText(shape_code)
                self.status_label.setText("Shape Code 生成成功")
            else:
                error = result.unwrap_err()
                QMessageBox.critical(self, "错误", f"生成失败:\n{error}")
                self.status_label.setText("生成失败")
        
        except ImportError:
            QMessageBox.warning(
                self, "功能不可用",
                "自然语言处理功能需要 OpenAI API。\n请设置 OPENAI_API_KEY 环境变量。"
            )
            self.status_label.setText("就绪")
        
        finally:
            self.generate_btn.setEnabled(True)
    
    def on_compile_clicked(self):
        """Handle compile button click."""
        code = self.code_editor.toPlainText()
        
        if not code.strip():
            QMessageBox.warning(self, "警告", "请输入 Shape Code")
            return
        
        self.status_label.setText("正在编译...")
        
        # Parse
        parse_result = self.parser.parse(code)
        
        if parse_result.is_err():
            error = parse_result.unwrap_err()
            QMessageBox.critical(self, "解析错误", str(error))
            self.status_label.setText("编译失败")
            return
        
        ast = parse_result.unwrap()
        
        # Validate
        validate_result = self.parser.validate(ast)
        
        if validate_result.is_err():
            error = validate_result.unwrap_err()
            QMessageBox.critical(self, "验证错误", str(error))
            self.status_label.setText("编译失败")
            return
        
        # Compile
        resolution = self.preferences.get('export', {}).get('default_resolution', 'medium')
        options = CompilerOptions(resolution=resolution)
        self.compiler = Compiler(options)
        
        compile_result = self.compiler.compile(ast)
        
        if compile_result.is_err():
            error = compile_result.unwrap_err()
            QMessageBox.critical(self, "编译错误", str(error))
            self.status_label.setText("编译失败")
            return
        
        result = compile_result.unwrap()
        
        # Update status
        self.status_label.setText("编译成功")
        self.stats_label.setText(
            f"顶点: {result.vertex_count:,} | 面: {result.face_count:,}"
        )
        
        QMessageBox.information(
            self, "编译成功",
            f"编译完成！\n\n顶点数: {result.vertex_count:,}\n面数: {result.face_count:,}"
        )
    
    def on_export_clicked(self):
        """Handle export button click."""
        if self.compiler is None:
            QMessageBox.warning(self, "警告", "请先编译 Shape Code")
            return
        
        # Get last compilation result
        code = self.code_editor.toPlainText()
        parse_result = self.parser.parse(code)
        
        if parse_result.is_err():
            QMessageBox.warning(self, "警告", "请先成功编译 Shape Code")
            return
        
        ast = parse_result.unwrap()
        compile_result = self.compiler.compile(ast)
        
        if compile_result.is_err():
            QMessageBox.warning(self, "警告", "请先成功编译 Shape Code")
            return
        
        result = compile_result.unwrap()
        
        if result.mesh is None:
            QMessageBox.warning(self, "警告", "没有可导出的网格")
            return
        
        # Show file dialog
        default_format = self.preferences.get('export', {}).get('default_format', 'stl')
        filter_str = "STL Files (*.stl);;OBJ Files (*.obj);;All Files (*)"
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "导出模型", f"output.{default_format}", filter_str
        )
        
        if not filepath:
            return
        
        # Determine format from extension
        ext = Path(filepath).suffix.lower()
        
        if ext == '.stl':
            export_result = self.compiler.export_stl(result.mesh, filepath)
        elif ext == '.obj':
            export_result = self.compiler.export_obj(result.mesh, filepath)
        else:
            QMessageBox.warning(self, "警告", "不支持的文件格式")
            return
        
        if export_result.is_ok():
            file_size = Path(filepath).stat().st_size
            QMessageBox.information(
                self, "导出成功",
                f"模型已导出到:\n{filepath}\n\n文件大小: {file_size:,} 字节"
            )
            self.status_label.setText(f"已导出: {Path(filepath).name}")
        else:
            error = export_result.unwrap_err()
            QMessageBox.critical(self, "导出错误", str(error))
    
    def on_file_new(self):
        """Handle new file."""
        if self.check_unsaved_changes():
            self.code_editor.clear()
            self.current_file = None
            self.is_modified = False
            self.update_window_title()
            self.status_label.setText("新建文件")
    
    def on_file_open(self):
        """Handle open file."""
        if not self.check_unsaved_changes():
            return
        
        filepath, _ = QFileDialog.getOpenFileName(
            self, "打开文件", "", "Shape Code Files (*.shapecode);;All Files (*)"
        )
        
        if filepath:
            self.load_file(filepath)
    
    def on_file_save(self):
        """Handle save file."""
        if self.current_file:
            self.save_file(self.current_file)
        else:
            self.on_file_save_as()
    
    def on_file_save_as(self):
        """Handle save as."""
        filepath, _ = QFileDialog.getSaveFileName(
            self, "另存为", "", "Shape Code Files (*.shapecode);;All Files (*)"
        )
        
        if filepath:
            self.save_file(filepath)
    
    def load_file(self, filepath):
        """Load a file."""
        result = self.file_manager.load_shapecode(filepath)
        
        if result.is_ok():
            content = result.unwrap()
            self.code_editor.setPlainText(content)
            self.current_file = filepath
            self.is_modified = False
            self.update_window_title()
            self.file_manager.add_recent_file(filepath)
            self.status_label.setText(f"已打开: {Path(filepath).name}")
        else:
            error = result.unwrap_err()
            QMessageBox.critical(self, "错误", f"无法打开文件:\n{error}")
    
    def save_file(self, filepath):
        """Save to a file."""
        content = self.code_editor.toPlainText()
        result = self.file_manager.save_shapecode(content, filepath)
        
        if result.is_ok():
            self.current_file = filepath
            self.is_modified = False
            self.update_window_title()
            self.file_manager.add_recent_file(filepath)
            self.status_label.setText(f"已保存: {Path(filepath).name}")
        else:
            error = result.unwrap_err()
            QMessageBox.critical(self, "错误", f"无法保存文件:\n{error}")
    
    def load_example(self, example_path):
        """Load an example."""
        if not self.check_unsaved_changes():
            return
        
        result = self.file_manager.load_example(example_path)
        
        if result.is_ok():
            content = result.unwrap()
            self.code_editor.setPlainText(content)
            self.current_file = None
            self.is_modified = False
            self.update_window_title()
            self.status_label.setText(f"已加载示例: {Path(example_path).stem}")
        else:
            error = result.unwrap_err()
            QMessageBox.critical(self, "错误", f"无法加载示例:\n{error}")
    
    def on_text_changed(self):
        """Handle text change."""
        self.is_modified = True
        self.update_window_title()
    
    def check_unsaved_changes(self):
        """Check for unsaved changes."""
        if self.is_modified:
            reply = QMessageBox.question(
                self, "未保存的更改",
                "文件已修改，是否保存？",
                QMessageBox.StandardButton.Save |
                QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Save:
                self.on_file_save()
                return True
            elif reply == QMessageBox.StandardButton.Discard:
                return True
            else:
                return False
        
        return True
    
    def update_window_title(self):
        """Update window title."""
        title = "Shape Code"
        
        if self.current_file:
            title += f" - {Path(self.current_file).name}"
        else:
            title += " - 未命名"
        
        if self.is_modified:
            title += " *"
        
        self.setWindowTitle(title)
    
    def show_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self, "关于 Shape Code",
            "<h2>Shape Code 0.1.0</h2>"
            "<p>一个用于 3D 建模的领域特定语言</p>"
            "<p>特性:</p>"
            "<ul>"
            "<li>简洁的语法</li>"
            "<li>AI 驱动的代码生成</li>"
            "<li>实时 3D 预览</li>"
            "<li>STL/OBJ 导出</li>"
            "</ul>"
        )
    
    def restore_window_state(self):
        """Restore window state from preferences."""
        window_prefs = self.preferences.get('window', {})
        
        width = window_prefs.get('width', 1200)
        height = window_prefs.get('height', 800)
        self.resize(width, height)
        
        if window_prefs.get('maximized', False):
            self.showMaximized()
    
    def closeEvent(self, event):
        """Handle window close event."""
        if self.check_unsaved_changes():
            # Save window state
            window_prefs = {
                'width': self.width(),
                'height': self.height(),
                'maximized': self.isMaximized()
            }
            
            prefs = self.preferences.copy()
            prefs['window'] = window_prefs
            self.file_manager.save_preferences(prefs)
            
            event.accept()
        else:
            event.ignore()
