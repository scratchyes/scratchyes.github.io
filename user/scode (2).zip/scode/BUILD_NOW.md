# 立即构建 Windows 可执行文件

## 快速构建步骤

### 方法 1: 使用 Python 脚本（推荐）

在命令提示符或 PowerShell 中运行：

```bash
python build_exe.py
```

### 方法 2: 手动构建

#### 步骤 1: 安装 PyInstaller
```bash
pip install pyinstaller
```

#### 步骤 2: 运行构建
```bash
pyinstaller shapecode.spec --clean
```

#### 步骤 3: 查找可执行文件
构建完成后，可执行文件位于：
```
dist\ShapeCode.exe
```

## 构建时间

- 首次构建: 约 3-5 分钟
- 后续构建: 约 1-2 分钟

## 构建后的文件大小

预计约 50-100 MB

## 如果构建失败

### 问题 1: pip 命令不可用
```bash
# 使用 python -m pip
python -m pip install pyinstaller
```

### 问题 2: PyInstaller 未找到
```bash
# 确认安装
python -m pip list | findstr pyinstaller

# 重新安装
python -m pip install --upgrade pyinstaller
```

### 问题 3: 缺少依赖
```bash
# 安装所有依赖
pip install -r requirements.txt
```

## 验证构建

构建成功后，测试可执行文件：

```bash
# 查看版本
dist\ShapeCode.exe --version

# 运行 CLI 模式
dist\ShapeCode.exe --cli examples\shapecode\basic\cube.shapecode -o test.stl

# 运行 GUI 模式
dist\ShapeCode.exe
```

## 分发

构建成功后，你可以：

1. **直接使用**
   ```bash
   dist\ShapeCode.exe
   ```

2. **分发给其他人**
   - 将 `dist\ShapeCode.exe` 复制给其他用户
   - 用户无需安装 Python 即可运行

3. **创建快捷方式**
   - 右键点击 `dist\ShapeCode.exe`
   - 选择"创建快捷方式"
   - 将快捷方式移动到桌面

## 当前状态

✅ 所有构建文件已准备就绪：
- `shapecode.spec` - PyInstaller 配置
- `build_exe.py` - Python 构建脚本
- `build.bat` - 批处理构建脚本

⏳ 等待构建：
- `dist\ShapeCode.exe` - 需要运行构建命令生成

## 需要帮助？

如果遇到问题，请查看：
- `BUILD_EXECUTABLE.md` - 详细构建说明
- `build_instructions.md` - 完整构建指南
- `EXECUTABLE_INFO.md` - 可执行文件说明

## 一键构建命令

在 PowerShell 中复制粘贴以下命令：

```powershell
# 安装 PyInstaller 并构建
python -m pip install pyinstaller; python -m PyInstaller shapecode.spec --clean
```

构建完成后，可执行文件将位于 `dist\ShapeCode.exe`
