# Shape Code Examples

This directory contains example Shape Code files demonstrating various features.

## Directory Structure

- `basic/` - Basic shape primitives
- `transforms/` - Transformation operations
- `boolean/` - Boolean operations
- `complex/` - Complex shape combinations
