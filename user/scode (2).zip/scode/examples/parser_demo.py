"""
Demonstration of the Shape Code parser.

This example shows how to use the lexer, parser, and validator
to process Shape Code programs.
"""

from src.parser import Parser


def demo_basic_parsing():
    """Demonstrate basic parsing."""
    print("=" * 60)
    print("Basic Parsing Demo")
    print("=" * 60)
    
    parser = Parser()
    
    code = """
# Create a cube
cube = Cube(size=[10, 10, 10])

# Create a sphere
sphere = Sphere(radius=5)

# Combine them
result = cube + sphere

# Export
export(result, "output.stl")
"""
    
    print("\nShape Code:")
    print(code)
    
    # Parse
    result = parser.parse(code)
    
    if result.is_ok():
        ast = result.unwrap()
        print(f"\n✓ Parsing successful!")
        print(f"  Generated {len(ast)} AST nodes\n")
        
        # Display AST
        for i, node in enumerate(ast, 1):
            print(f"  {i}. {node}")
        
        # Validate
        validate_result = parser.validate(ast)
        if validate_result.is_ok():
            print(f"\n✓ Validation successful!")
        else:
            print(f"\n✗ Validation failed:")
            print(f"  {validate_result.unwrap_err()}")
    else:
        print(f"\n✗ Parsing failed:")
        print(f"  {result.unwrap_err()}")


def demo_error_handling():
    """Demonstrate error handling."""
    print("\n" + "=" * 60)
    print("Error Handling Demo")
    print("=" * 60)
    
    parser = Parser()
    
    # Example 1: Syntax error
    print("\n[Example 1] Syntax Error")
    code = "cube = Cube(size=[10, 10, 10]"  # Missing closing paren
    print(f"Code: {code}")
    
    result = parser.parse(code)
    if result.is_err():
        print(f"✓ Detected error: {result.unwrap_err()}")
    
    # Example 2: Undefined variable
    print("\n[Example 2] Undefined Variable")
    code = "result = undefined_var.translate([1, 2, 3])"
    print(f"Code: {code}")
    
    result = parser.parse(code)
    if result.is_ok():
        ast = result.unwrap()
        validate_result = parser.validate(ast)
        if validate_result.is_err():
            print(f"✓ Detected error: {validate_result.unwrap_err()}")
    
    # Example 3: Invalid parameter
    print("\n[Example 3] Invalid Parameter Value")
    code = "sphere = Sphere(radius=-5)"
    print(f"Code: {code}")
    
    result = parser.parse(code)
    if result.is_ok():
        ast = result.unwrap()
        validate_result = parser.validate(ast)
        if validate_result.is_err():
            print(f"✓ Detected error: {validate_result.unwrap_err()}")


def demo_complex_expressions():
    """Demonstrate complex expressions."""
    print("\n" + "=" * 60)
    print("Complex Expressions Demo")
    print("=" * 60)
    
    parser = Parser()
    
    code = """
# Create base shapes
base = Cube(size=[20, 20, 20])
hole = Sphere(radius=12)

# Create the difference
hollowed = base - hole

# Transform it
positioned = hollowed.translate([0, 0, 10]).rotate([0, 0, 45])

# Add a top piece
top = Cylinder(radius=5, height=15)
top_positioned = top.translate([0, 0, 20])

# Final assembly
final = positioned + top_positioned

# Export
export(final, "complex_model.stl")
"""
    
    print("\nShape Code:")
    print(code)
    
    result = parser.parse(code)
    
    if result.is_ok():
        ast = result.unwrap()
        print(f"\n✓ Parsing successful!")
        print(f"  Generated {len(ast)} AST nodes")
        
        validate_result = parser.validate(ast)
        if validate_result.is_ok():
            print(f"✓ Validation successful!")
            print(f"\nThis code defines a complex 3D model with:")
            print(f"  - Boolean operations (difference, union)")
            print(f"  - Multiple transformations (translate, rotate)")
            print(f"  - Multiple primitive shapes (cube, sphere, cylinder)")
        else:
            print(f"\n✗ Validation failed:")
            print(f"  {validate_result.unwrap_err()}")
    else:
        print(f"\n✗ Parsing failed:")
        print(f"  {result.unwrap_err()}")


if __name__ == "__main__":
    demo_basic_parsing()
    demo_error_handling()
    demo_complex_expressions()
    
    print("\n" + "=" * 60)
    print("Demo completed!")
    print("=" * 60)
