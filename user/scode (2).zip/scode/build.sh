#!/bin/bash
# Shape Code 构建脚本 (Linux/Mac)

echo "========================================"
echo "Shape Code 可执行文件构建"
echo "========================================"
echo

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未找到 Python，请先安装 Python 3.8+"
    exit 1
fi

echo "[1/4] 检查 PyInstaller..."
if ! python3 -m PyInstaller --version &> /dev/null; then
    echo "PyInstaller 未安装，正在安装..."
    python3 -m pip install pyinstaller
    if [ $? -ne 0 ]; then
        echo "[错误] PyInstaller 安装失败"
        exit 1
    fi
fi
echo "[✓] PyInstaller 已就绪"

echo
echo "[2/4] 检查依赖..."
python3 -m pip install -r requirements.txt --quiet
if [ $? -ne 0 ]; then
    echo "[警告] 部分依赖安装失败，继续构建..."
fi
echo "[✓] 依赖检查完成"

echo
echo "[3/4] 开始构建可执行文件..."
echo "这可能需要几分钟时间，请耐心等待..."
python3 -m PyInstaller shapecode.spec --clean
if [ $? -ne 0 ]; then
    echo "[错误] 构建失败"
    exit 1
fi
echo "[✓] 构建完成"

echo
echo "[4/4] 验证构建结果..."
if [ -f "dist/ShapeCode" ]; then
    echo "[✓] 可执行文件已生成: dist/ShapeCode"
    
    # 获取文件大小
    size=$(du -h dist/ShapeCode | cut -f1)
    echo "[✓] 文件大小: $size"
    
    # 添加执行权限
    chmod +x dist/ShapeCode
    
    echo
    echo "========================================"
    echo "构建成功！"
    echo "========================================"
    echo
    echo "可执行文件位置: dist/ShapeCode"
    echo
    echo "你可以:"
    echo "  1. 直接运行: ./dist/ShapeCode"
    echo "  2. 分发给其他用户（无需安装 Python）"
    echo "  3. 移动到 /usr/local/bin 以全局使用"
    echo
else
    echo "[错误] 未找到可执行文件"
    exit 1
fi
