"""Lexical analyzer for Shape Code language."""

from typing import List, Optional, Any
from dataclasses import dataclass
import ply.lex as lex


@dataclass
class Token:
    """Represents a lexical token."""
    type: str
    value: Any
    line: int
    column: int
    
    def __repr__(self) -> str:
        return f"Token({self.type}, {self.value!r}, {self.line}:{self.column})"


class Lexer:
    """Lexical analyzer for Shape Code using PLY."""
    
    # Token names
    tokens = (
        'IDENTIFIER',
        'NUMBER',
        'STRING',
        'LPAREN',
        'RPAREN',
        'LBRACKET',
        'RBRACKET',
        'COMMA',
        'EQUALS',
        'PLUS',
        'MINUS',
        'AMPERSAND',
        'DOT',
        # Keywords
        'CUBE',
        'SPHERE',
        'CYLINDER',
        'CONE',
        'TRANSLATE',
        'ROTATE',
        'SCALE',
        'EXPORT',
    )
    
    # Reserved keywords
    reserved = {
        'Cube': 'CUBE',
        'Sphere': 'SPHERE',
        'Cylinder': 'CYLINDER',
        'Cone': 'CONE',
        'translate': 'TRANSLATE',
        'rotate': 'ROTATE',
        'scale': 'SCALE',
        'export': 'EXPORT',
    }
    
    # Token rules
    t_LPAREN = r'\('
    t_RPAREN = r'\)'
    t_LBRACKET = r'\['
    t_RBRACKET = r'\]'
    t_COMMA = r','
    t_EQUALS = r'='
    t_PLUS = r'\+'
    t_MINUS = r'-'
    t_AMPERSAND = r'&'
    t_DOT = r'\.'
    
    # Ignored characters (spaces and tabs)
    t_ignore = ' \t'
    
    def __init__(self):
        """Initialize the lexer."""
        self.lexer = None
        self.tokens_list: List[Token] = []
        self.line_starts: List[int] = [0]  # Track start position of each line
    
    def t_NUMBER(self, t):
        r'\d+\.?\d*'
        t.value = float(t.value) if '.' in t.value else int(t.value)
        return t
    
    def t_STRING(self, t):
        r'"([^"\\]|\\.)*"'
        # Remove quotes
        t.value = t.value[1:-1]
        return t
    
    def t_IDENTIFIER(self, t):
        r'[a-zA-Z_][a-zA-Z0-9_]*'
        # Check if it's a reserved keyword
        t.type = self.reserved.get(t.value, 'IDENTIFIER')
        return t
    
    def t_COMMENT(self, t):
        r'\#[^\n]*'
        # Ignore comments
        pass
    
    def t_newline(self, t):
        r'\n+'
        t.lexer.lineno += len(t.value)
        # Track line start positions for column calculation
        self.line_starts.append(t.lexer.lexpos)
    
    def t_error(self, t):
        """Handle lexical errors."""
        line = t.lineno
        column = self._get_column(t.lexpos)
        raise SyntaxError(f"Illegal character '{t.value[0]}' at line {line}, column {column}")
    
    def _get_column(self, lexpos: int) -> int:
        """Calculate column number from lexer position."""
        # Find the line this position belongs to
        line_num = 1
        for i, start_pos in enumerate(self.line_starts):
            if lexpos >= start_pos:
                line_num = i + 1
            else:
                break
        
        # Column is position minus start of current line
        if line_num > 0 and line_num <= len(self.line_starts):
            line_start = self.line_starts[line_num - 1]
            return lexpos - line_start + 1
        return 1
    
    def tokenize(self, code: str) -> List[Token]:
        """
        Tokenize Shape Code input.
        
        Args:
            code: Shape Code source string
            
        Returns:
            List of Token objects
            
        Raises:
            SyntaxError: If lexical errors are encountered
        """
        # Reset state
        self.tokens_list = []
        self.line_starts = [0]
        
        # Build lexer if not already built
        if self.lexer is None:
            self.lexer = lex.lex(module=self)
        
        # Reset lexer state
        self.lexer.lineno = 1
        
        # Tokenize
        self.lexer.input(code)
        
        for tok in self.lexer:
            column = self._get_column(tok.lexpos)
            token = Token(
                type=tok.type,
                value=tok.value,
                line=tok.lineno,
                column=column
            )
            self.tokens_list.append(token)
        
        return self.tokens_list
