"""File manager for Shape Code files and examples."""

import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from src.errors import ShapeCodeError
from src.result import Result


class FileManager:
    """Manager for Shape Code files, examples, and preferences."""
    
    def __init__(self, config_dir: Optional[str] = None):
        """
        Initialize the file manager.
        
        Args:
            config_dir: Configuration directory (defaults to ~/.shapecode)
        """
        if config_dir is None:
            self.config_dir = Path.home() / '.shapecode'
        else:
            self.config_dir = Path(config_dir)
        
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.preferences_file = self.config_dir / 'preferences.json'
    
    def save_shapecode(self, code: str, filepath: str) -> Result[None, ShapeCodeError]:
        """
        Save Shape Code to a file.
        
        Args:
            code: Shape Code content
            filepath: Output file path
            
        Returns:
            Result indicating success or ShapeCodeError
        """
        try:
            # Validate path security
            path_result = self._validate_path(filepath, check_extension=True)
            if path_result.is_err():
                return Result.Err(path_result.unwrap_err())
            
            path = path_result.unwrap()
            
            # Check content size (max 10MB)
            if len(code) > 10 * 1024 * 1024:
                return Result.Err(ShapeCodeError("Content too large (max 10MB)"))
            
            path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write(code)
            
            return Result.Ok(None)
            
        except IOError as e:
            return Result.Err(ShapeCodeError(f"Failed to save file: {str(e)}"))
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Unexpected error saving file: {str(e)}"))
    
    def load_shapecode(self, filepath: str) -> Result[str, ShapeCodeError]:
        """
        Load Shape Code from a file.
        
        Args:
            filepath: Input file path
            
        Returns:
            Result containing file content or ShapeCodeError
        """
        try:
            # Validate path security
            path_result = self._validate_path(filepath)
            if path_result.is_err():
                return Result.Err(path_result.unwrap_err())
            
            path = path_result.unwrap()
            
            if not path.exists():
                return Result.Err(ShapeCodeError(f"File not found: {filepath}"))
            
            if not path.is_file():
                return Result.Err(ShapeCodeError(f"Not a file: {filepath}"))
            
            # Check file size (max 10MB)
            file_size = path.stat().st_size
            if file_size > 10 * 1024 * 1024:
                return Result.Err(ShapeCodeError("File too large (max 10MB)"))
            
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return Result.Ok(content)
            
        except IOError as e:
            return Result.Err(ShapeCodeError(f"Failed to load file: {str(e)}"))
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Unexpected error loading file: {str(e)}"))
    
    def load_example(self, example_name: str) -> Result[str, ShapeCodeError]:
        """
        Load an example Shape Code file.
        
        Args:
            example_name: Name of the example (e.g., 'basic/cube')
            
        Returns:
            Result containing example content or ShapeCodeError
        """
        try:
            # Look for example in examples directory
            examples_dir = Path(__file__).parent.parent / 'examples' / 'shapecode'
            example_path = examples_dir / f"{example_name}.shapecode"
            
            if not example_path.exists():
                return Result.Err(ShapeCodeError(f"Example not found: {example_name}"))
            
            return self.load_shapecode(str(example_path))
            
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Failed to load example: {str(e)}"))
    
    def list_examples(self) -> Result[Dict[str, List[str]], ShapeCodeError]:
        """
        List all available examples organized by category.
        
        Returns:
            Result containing dict of category -> list of example names
        """
        try:
            examples_dir = Path(__file__).parent.parent / 'examples' / 'shapecode'
            
            if not examples_dir.exists():
                return Result.Ok({})
            
            examples = {}
            
            for category_dir in examples_dir.iterdir():
                if category_dir.is_dir():
                    category = category_dir.name
                    examples[category] = []
                    
                    for example_file in category_dir.glob('*.shapecode'):
                        example_name = example_file.stem
                        examples[category].append(f"{category}/{example_name}")
            
            return Result.Ok(examples)
            
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Failed to list examples: {str(e)}"))
    
    def save_preferences(self, preferences: Dict[str, Any]) -> Result[None, ShapeCodeError]:
        """
        Save user preferences.
        
        Args:
            preferences: Preferences dictionary
            
        Returns:
            Result indicating success or ShapeCodeError
        """
        try:
            with open(self.preferences_file, 'w', encoding='utf-8') as f:
                json.dump(preferences, f, indent=2)
            
            return Result.Ok(None)
            
        except IOError as e:
            return Result.Err(ShapeCodeError(f"Failed to save preferences: {str(e)}"))
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Unexpected error saving preferences: {str(e)}"))
    
    def load_preferences(self) -> Result[Dict[str, Any], ShapeCodeError]:
        """
        Load user preferences.
        
        Returns:
            Result containing preferences dict or ShapeCodeError
        """
        try:
            if not self.preferences_file.exists():
                # Return default preferences
                return Result.Ok(self._get_default_preferences())
            
            with open(self.preferences_file, 'r', encoding='utf-8') as f:
                preferences = json.load(f)
            
            return Result.Ok(preferences)
            
        except IOError as e:
            return Result.Err(ShapeCodeError(f"Failed to load preferences: {str(e)}"))
        except json.JSONDecodeError as e:
            return Result.Err(ShapeCodeError(f"Invalid preferences file: {str(e)}"))
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Unexpected error loading preferences: {str(e)}"))
    
    def add_recent_file(self, filepath: str) -> Result[None, ShapeCodeError]:
        """
        Add a file to the recent files list.
        
        Args:
            filepath: File path to add
            
        Returns:
            Result indicating success or ShapeCodeError
        """
        try:
            prefs_result = self.load_preferences()
            if prefs_result.is_err():
                return Result.Err(prefs_result.unwrap_err())
            
            preferences = prefs_result.unwrap()
            recent_files = preferences.get('recent_files', [])
            
            # Remove if already in list
            if filepath in recent_files:
                recent_files.remove(filepath)
            
            # Add to front
            recent_files.insert(0, filepath)
            
            # Keep only last 10
            recent_files = recent_files[:10]
            
            preferences['recent_files'] = recent_files
            
            return self.save_preferences(preferences)
            
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Failed to add recent file: {str(e)}"))
    
    def get_recent_files(self) -> Result[List[str], ShapeCodeError]:
        """
        Get the list of recent files.
        
        Returns:
            Result containing list of recent file paths
        """
        try:
            prefs_result = self.load_preferences()
            if prefs_result.is_err():
                return Result.Err(prefs_result.unwrap_err())
            
            preferences = prefs_result.unwrap()
            recent_files = preferences.get('recent_files', [])
            
            # Filter out files that no longer exist
            existing_files = [f for f in recent_files if Path(f).exists()]
            
            return Result.Ok(existing_files)
            
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Failed to get recent files: {str(e)}"))
    
    def _validate_path(self, filepath: str, check_extension: bool = False) -> Result[Path, ShapeCodeError]:
        """
        Validate file path for security.
        
        Args:
            filepath: Path to validate
            check_extension: Whether to check file extension
            
        Returns:
            Result containing validated Path or ShapeCodeError
        """
        try:
            # Resolve to absolute path
            path = Path(filepath).resolve()
            
            # Check for path traversal attempts
            if '..' in filepath or filepath.startswith('/'):
                return Result.Err(ShapeCodeError("Invalid path: path traversal not allowed"))
            
            # Validate file extension if requested
            if check_extension:
                allowed_extensions = ['.shapecode', '.txt', '.sc']
                if path.suffix.lower() not in allowed_extensions:
                    return Result.Err(ShapeCodeError(
                        f"Invalid file extension. Allowed: {', '.join(allowed_extensions)}"
                    ))
            
            return Result.Ok(path)
            
        except Exception as e:
            return Result.Err(ShapeCodeError(f"Invalid path: {str(e)}"))
    
    def _get_default_preferences(self) -> Dict[str, Any]:
        """Get default preferences."""
        return {
            'recent_files': [],
            'window': {
                'width': 1200,
                'height': 800,
                'maximized': False
            },
            'editor': {
                'font_size': 12,
                'font_family': 'Consolas',
                'tab_size': 4,
                'auto_indent': True
            },
            'export': {
                'default_format': 'stl',
                'default_resolution': 'medium',
                'optimize_mesh': True
            },
            'api': {
                'openai_model': 'gpt-4'
            }
        }
