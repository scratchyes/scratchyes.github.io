"""Semantic validator for Shape Code AST."""

from typing import List, Set, Dict, Any
from src.ast_nodes import (
    ASTNode, Assignment, Primitive, Transform, 
    BooleanOp, Identifier, Export
)
from src.errors import ValidationError
from src.result import Result


class Validator:
    """Semantic validator for Shape Code AST."""
    
    # Valid parameter names for each primitive type
    PRIMITIVE_PARAMS = {
        'cube': {'size'},
        'sphere': {'radius', 'subdivisions'},
        'cylinder': {'radius', 'height', 'segments'},
        'cone': {'radius', 'height', 'segments'}
    }
    
    # Required parameters for each primitive type
    REQUIRED_PARAMS = {
        'cube': {'size'},
        'sphere': {'radius'},
        'cylinder': {'radius', 'height'},
        'cone': {'radius', 'height'}
    }
    
    def __init__(self):
        """Initialize the validator."""
        self.symbol_table: Dict[str, ASTNode] = {}
        self.errors: List[ValidationError] = []
    
    def validate(self, ast: List[ASTNode]) -> Result[None, ValidationError]:
        """
        Validate the semantic correctness of an AST.
        
        Args:
            ast: List of AST nodes to validate
            
        Returns:
            Result indicating success or containing ValidationError
        """
        self.symbol_table = {}
        self.errors = []
        
        try:
            for node in ast:
                self._validate_node(node)
            
            if self.errors:
                # Return the first error
                return Result.Err(self.errors[0])
            
            return Result.Ok(None)
            
        except ValidationError as e:
            return Result.Err(e)
    
    def _validate_node(self, node: ASTNode) -> None:
        """Validate a single AST node."""
        if isinstance(node, Assignment):
            self._validate_assignment(node)
        elif isinstance(node, Export):
            self._validate_export(node)
        elif isinstance(node, Primitive):
            self._validate_primitive(node)
        elif isinstance(node, Transform):
            self._validate_transform(node)
        elif isinstance(node, BooleanOp):
            self._validate_boolean_op(node)
        elif isinstance(node, Identifier):
            self._validate_identifier(node)
    
    def _validate_assignment(self, node: Assignment) -> None:
        """Validate an assignment statement."""
        # Validate the expression
        self._validate_node(node.expression)
        
        # Add to symbol table
        self.symbol_table[node.identifier] = node.expression
    
    def _validate_export(self, node: Export) -> None:
        """Validate an export statement."""
        # Validate the expression
        self._validate_node(node.expression)
        
        # Validate filepath
        if not node.filepath:
            self._add_error(
                "Export filepath cannot be empty",
                node.line,
                node.column,
                "Provide a valid filepath for export"
            )
        
        # Check file extension
        valid_extensions = ['.stl', '.obj']
        if not any(node.filepath.endswith(ext) for ext in valid_extensions):
            self._add_error(
                f"Invalid file extension in '{node.filepath}'",
                node.line,
                node.column,
                f"Use one of: {', '.join(valid_extensions)}"
            )
    
    def _validate_primitive(self, node: Primitive) -> None:
        """Validate a primitive shape."""
        shape_type = node.shape_type
        
        # Check if shape type is valid
        if shape_type not in self.PRIMITIVE_PARAMS:
            self._add_error(
                f"Unknown primitive type '{shape_type}'",
                node.line,
                node.column,
                f"Valid types: {', '.join(self.PRIMITIVE_PARAMS.keys())}"
            )
            return
        
        # Check required parameters
        required = self.REQUIRED_PARAMS[shape_type]
        provided = set(node.params.keys())
        missing = required - provided
        
        if missing:
            self._add_error(
                f"Missing required parameter(s) for {shape_type}: {', '.join(missing)}",
                node.line,
                node.column,
                f"Add the missing parameter(s)"
            )
        
        # Check for invalid parameters
        valid = self.PRIMITIVE_PARAMS[shape_type]
        invalid = provided - valid
        
        if invalid:
            self._add_error(
                f"Invalid parameter(s) for {shape_type}: {', '.join(invalid)}",
                node.line,
                node.column,
                f"Valid parameters: {', '.join(valid)}"
            )
        
        # Validate parameter values
        for param_name, param_value in node.params.items():
            self._validate_param_value(shape_type, param_name, param_value, node)
    
    def _validate_param_value(
        self, 
        shape_type: str, 
        param_name: str, 
        param_value: Any,
        node: ASTNode
    ) -> None:
        """Validate a parameter value."""
        if param_name == 'size':
            # Size should be a list of 3 numbers
            if not isinstance(param_value, list):
                self._add_error(
                    f"Parameter 'size' must be a vector [x, y, z]",
                    node.line,
                    node.column,
                    "Use format: size=[10, 10, 10]"
                )
            elif len(param_value) != 3:
                self._add_error(
                    f"Parameter 'size' must have exactly 3 values, got {len(param_value)}",
                    node.line,
                    node.column,
                    "Use format: size=[x, y, z]"
                )
            elif not all(isinstance(v, (int, float)) and v > 0 for v in param_value):
                self._add_error(
                    f"All size values must be positive numbers",
                    node.line,
                    node.column,
                    "Ensure all values are greater than 0"
                )
        
        elif param_name in ['radius', 'height']:
            # Radius and height should be positive numbers
            if not isinstance(param_value, (int, float)):
                self._add_error(
                    f"Parameter '{param_name}' must be a number",
                    node.line,
                    node.column,
                    f"Use format: {param_name}=5"
                )
            elif param_value <= 0:
                self._add_error(
                    f"Parameter '{param_name}' must be positive, got {param_value}",
                    node.line,
                    node.column,
                    "Use a value greater than 0"
                )
        
        elif param_name in ['subdivisions', 'segments']:
            # Subdivisions and segments should be positive integers
            if not isinstance(param_value, int):
                self._add_error(
                    f"Parameter '{param_name}' must be an integer",
                    node.line,
                    node.column,
                    f"Use format: {param_name}=32"
                )
            elif param_value < 3:
                self._add_error(
                    f"Parameter '{param_name}' must be at least 3, got {param_value}",
                    node.line,
                    node.column,
                    "Use a value of 3 or greater"
                )
    
    def _validate_transform(self, node: Transform) -> None:
        """Validate a transform operation."""
        # Validate the target
        self._validate_node(node.target)
        
        # Validate transform parameters
        if not isinstance(node.params, list):
            self._add_error(
                f"Transform parameters must be a vector",
                node.line,
                node.column,
                "Use format: .translate([x, y, z])"
            )
            return
        
        if len(node.params) != 3:
            self._add_error(
                f"Transform '{node.transform_type}' requires exactly 3 values, got {len(node.params)}",
                node.line,
                node.column,
                f"Use format: .{node.transform_type}([x, y, z])"
            )
        
        if not all(isinstance(v, (int, float)) for v in node.params):
            self._add_error(
                f"All transform values must be numbers",
                node.line,
                node.column,
                "Ensure all values are numeric"
            )
        
        # Validate scale factors are positive
        if node.transform_type == 'scale':
            if not all(v > 0 for v in node.params):
                self._add_error(
                    f"Scale factors must be positive",
                    node.line,
                    node.column,
                    "Use positive values for scaling"
                )
    
    def _validate_boolean_op(self, node: BooleanOp) -> None:
        """Validate a boolean operation."""
        # Validate both operands
        self._validate_node(node.left)
        self._validate_node(node.right)
    
    def _validate_identifier(self, node: Identifier) -> None:
        """Validate an identifier reference."""
        if node.name not in self.symbol_table:
            self._add_error(
                f"Undefined variable '{node.name}'",
                node.line,
                node.column,
                f"Define '{node.name}' before using it"
            )
    
    def _add_error(
        self, 
        message: str, 
        line: int, 
        column: int, 
        suggestion: str
    ) -> None:
        """Add a validation error."""
        full_message = f"{message}\nSuggestion: {suggestion}"
        error = ValidationError(full_message, line, column)
        self.errors.append(error)
        
        # For now, raise immediately on first error
        raise error
