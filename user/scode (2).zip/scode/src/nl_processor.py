"""Natural language processor for generating Shape Code."""

import os
from typing import Optional
from openai import OpenAI
from src.errors import NLProcessError
from src.result import Result


class NLProcessor:
    """Processor for converting natural language to Shape Code."""
    
    SYSTEM_PROMPT = """You are a Shape Code generator. Shape Code is a domain-specific language for 3D modeling.

# Shape Code Syntax

## Primitives
- Cube(size=[x, y, z]) - Creates a cube
- Sphere(radius=r) - Creates a sphere
- Cylinder(radius=r, height=h) - Creates a cylinder
- Cone(radius=r, height=h) - Creates a cone

## Transformations
- .translate([x, y, z]) - Move shape
- .rotate([x, y, z]) - Rotate shape (degrees)
- .scale([x, y, z]) - Scale shape

## Boolean Operations
- shape1 + shape2 - Union (combine)
- shape1 - shape2 - Difference (subtract)
- shape1 & shape2 - Intersection (overlap)

## Export
- export(shape, "filename.stl") - Export to STL file

# Examples

Example 1: Simple cube
Input: "Create a 10x10x10 cube"
Output:
```
cube = Cube(size=[10, 10, 10])
export(cube, "cube.stl")
```

Example 2: Sphere moved up
Input: "Make a sphere with radius 5 and move it up by 10 units"
Output:
```
sphere = Sphere(radius=5)
moved_sphere = sphere.translate([0, 0, 10])
export(moved_sphere, "sphere.stl")
```

Example 3: Hollowed cube
Input: "Create a cube with a spherical hole in it"
Output:
```
cube = Cube(size=[20, 20, 20])
sphere = Sphere(radius=12)
hollowed = cube - sphere
export(hollowed, "hollowed_cube.stl")
```

Example 4: Snowman
Input: "Make a snowman with three spheres stacked vertically"
Output:
```
bottom = Sphere(radius=8)
middle = Sphere(radius=6)
middle_positioned = middle.translate([0, 0, 12])
head = Sphere(radius=4)
head_positioned = head.translate([0, 0, 20])
snowman = bottom + middle_positioned + head_positioned
export(snowman, "snowman.stl")
```

# Instructions
- Generate ONLY valid Shape Code
- Use descriptive variable names
- Add comments to explain complex operations
- Always include an export statement at the end
- Use reasonable default sizes and positions
- For spatial relationships:
  - "above" = positive Z translation
  - "below" = negative Z translation
  - "right" = positive X translation
  - "left" = negative X translation
  - "forward" = positive Y translation
  - "backward" = negative Y translation
"""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4"):
        """
        Initialize the NL processor.
        
        Args:
            api_key: OpenAI API key (defaults to OPENAI_API_KEY env var)
            model: OpenAI model to use
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        self.model = model
        self.client = None
        
        if self.api_key:
            # Validate API key format (basic check)
            if not self.api_key.startswith('sk-'):
                # Don't raise error, just log warning
                import warnings
                warnings.warn("API key format may be invalid")
            
            self.client = OpenAI(api_key=self.api_key)
    
    def process(self, natural_language: str) -> Result[str, NLProcessError]:
        """
        Convert natural language description to Shape Code.
        
        Args:
            natural_language: Natural language description
            
        Returns:
            Result containing Shape Code or NLProcessError
        """
        if not self.client:
            return Result.Err(NLProcessError(
                "OpenAI API key not configured. Please set OPENAI_API_KEY environment variable."
            ))
        
        try:
            prompt = self._build_prompt(natural_language)
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            shape_code = response.choices[0].message.content.strip()
            
            # Extract code from markdown code blocks if present
            if "```" in shape_code:
                lines = shape_code.split('\n')
                code_lines = []
                in_code_block = False
                
                for line in lines:
                    if line.strip().startswith('```'):
                        in_code_block = not in_code_block
                        continue
                    if in_code_block:
                        code_lines.append(line)
                
                shape_code = '\n'.join(code_lines)
            
            return Result.Ok(shape_code)
            
        except Exception as e:
            return Result.Err(NLProcessError(f"Failed to process natural language: {str(e)}"))
    
    def _build_prompt(self, natural_language: str) -> str:
        """Build the complete prompt for the API."""
        return f"""Convert the following description to Shape Code:

{natural_language}

Generate only the Shape Code, no explanations."""
