"""Abstract Syntax Tree node definitions for Shape Code."""

from typing import Any, Dict, List
from dataclasses import dataclass


@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int = 0
    column: int = 0


@dataclass
class Primitive(ASTNode):
    """Represents a basic geometric shape."""
    shape_type: str  # 'cube', 'sphere', 'cylinder', 'cone'
    params: Dict[str, Any]
    
    def __repr__(self) -> str:
        return f"Primitive({self.shape_type}, {self.params})"


@dataclass
class Transform(ASTNode):
    """Represents a transformation operation on a shape."""
    target: ASTNode
    transform_type: str  # 'translate', 'rotate', 'scale'
    params: List[float]
    
    def __repr__(self) -> str:
        return f"Transform({self.transform_type}, {self.params}, {self.target})"


@dataclass
class BooleanOp(ASTNode):
    """Represents a boolean operation between two shapes."""
    left: ASTNode
    right: ASTNode
    operation: str  # 'union', 'difference', 'intersection'
    
    def __repr__(self) -> str:
        return f"BooleanOp({self.operation}, {self.left}, {self.right})"


@dataclass
class Assignment(ASTNode):
    """Represents a variable assignment statement."""
    identifier: str
    expression: ASTNode
    
    def __repr__(self) -> str:
        return f"Assignment({self.identifier} = {self.expression})"


@dataclass
class Identifier(ASTNode):
    """Represents a variable reference."""
    name: str
    
    def __repr__(self) -> str:
        return f"Identifier({self.name})"


@dataclass
class Export(ASTNode):
    """Represents an export statement."""
    expression: ASTNode
    filepath: str
    
    def __repr__(self) -> str:
        return f"Export({self.expression}, {self.filepath})"
