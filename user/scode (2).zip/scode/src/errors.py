"""Error type hierarchy for Shape Code system."""

from typing import Optional


class ShapeCodeError(Exception):
    """Base error class for all Shape Code errors."""
    
    def __init__(
        self,
        message: str,
        line: Optional[int] = None,
        column: Optional[int] = None
    ):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        """Format error message with location information."""
        if self.line is not None and self.column is not None:
            return f"Line {self.line}, Column {self.column}: {self.message}"
        elif self.line is not None:
            return f"Line {self.line}: {self.message}"
        return self.message


class ParseError(ShapeCodeError):
    """Error during Shape Code parsing."""
    pass


class ValidationError(ShapeCodeError):
    """Error during semantic validation."""
    pass


class CompileError(ShapeCodeError):
    """Error during compilation to 3D mesh."""
    pass


class GeometryError(ShapeCodeError):
    """Error during geometric operations."""
    pass


class NLProcessError(ShapeCodeError):
    """Error during natural language processing."""
    pass
