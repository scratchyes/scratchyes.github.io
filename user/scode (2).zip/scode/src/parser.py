"""Parser for Shape Code language using PLY."""

from typing import List, Any
import ply.yacc as yacc

from src.lexer import Lexer, Token
from src.ast_nodes import (
    ASTNode, Primitive, Transform, BooleanOp, 
    Assignment, Identifier, Export
)
from src.errors import ParseError, ValidationError
from src.result import Result


class Parser:
    """Parser for Shape Code using PLY yacc."""
    
    def __init__(self):
        """Initialize the parser."""
        self.lexer = Lexer()
        self.tokens = self.lexer.tokens
        self.parser = None
        self.ast: List[ASTNode] = []
    
    # Operator precedence and associativity
    precedence = (
        ('left', 'PLUS', 'MINUS', 'AMPERSAND'),
        ('left', 'DOT'),
    )
    
    def p_program(self, p):
        """program : statement_list"""
        p[0] = p[1]
    
    def p_statement_list(self, p):
        """statement_list : statement_list statement
                         | statement"""
        if len(p) == 3:
            p[0] = p[1] + [p[2]]
        else:
            p[0] = [p[1]]
    
    def p_statement(self, p):
        """statement : assignment
                    | export"""
        p[0] = p[1]
    
    def p_assignment(self, p):
        """assignment : IDENTIFIER EQUALS expression"""
        p[0] = Assignment(
            identifier=p[1],
            expression=p[3],
            line=p.lineno(1),
            column=0
        )
    
    def p_export(self, p):
        """export : EXPORT LPAREN expression COMMA STRING RPAREN"""
        p[0] = Export(
            expression=p[3],
            filepath=p[5],
            line=p.lineno(1),
            column=0
        )
    
    def p_expression_primitive(self, p):
        """expression : primitive"""
        p[0] = p[1]
    
    def p_expression_transform(self, p):
        """expression : transform"""
        p[0] = p[1]
    
    def p_expression_boolean(self, p):
        """expression : boolean_op"""
        p[0] = p[1]
    
    def p_expression_identifier(self, p):
        """expression : IDENTIFIER"""
        p[0] = Identifier(
            name=p[1],
            line=p.lineno(1),
            column=0
        )
    
    def p_expression_paren(self, p):
        """expression : LPAREN expression RPAREN"""
        p[0] = p[2]
    
    def p_primitive_cube(self, p):
        """primitive : CUBE LPAREN params RPAREN"""
        p[0] = Primitive(
            shape_type='cube',
            params=p[3],
            line=p.lineno(1),
            column=0
        )
    
    def p_primitive_sphere(self, p):
        """primitive : SPHERE LPAREN params RPAREN"""
        p[0] = Primitive(
            shape_type='sphere',
            params=p[3],
            line=p.lineno(1),
            column=0
        )
    
    def p_primitive_cylinder(self, p):
        """primitive : CYLINDER LPAREN params RPAREN"""
        p[0] = Primitive(
            shape_type='cylinder',
            params=p[3],
            line=p.lineno(1),
            column=0
        )
    
    def p_primitive_cone(self, p):
        """primitive : CONE LPAREN params RPAREN"""
        p[0] = Primitive(
            shape_type='cone',
            params=p[3],
            line=p.lineno(1),
            column=0
        )
    
    def p_transform_translate(self, p):
        """transform : expression DOT TRANSLATE LPAREN vector RPAREN"""
        p[0] = Transform(
            target=p[1],
            transform_type='translate',
            params=p[5],
            line=p.lineno(3),
            column=0
        )
    
    def p_transform_rotate(self, p):
        """transform : expression DOT ROTATE LPAREN vector RPAREN"""
        p[0] = Transform(
            target=p[1],
            transform_type='rotate',
            params=p[5],
            line=p.lineno(3),
            column=0
        )
    
    def p_transform_scale(self, p):
        """transform : expression DOT SCALE LPAREN vector RPAREN"""
        p[0] = Transform(
            target=p[1],
            transform_type='scale',
            params=p[5],
            line=p.lineno(3),
            column=0
        )
    
    def p_boolean_op_union(self, p):
        """boolean_op : expression PLUS expression"""
        p[0] = BooleanOp(
            left=p[1],
            right=p[3],
            operation='union',
            line=p.lineno(2),
            column=0
        )
    
    def p_boolean_op_difference(self, p):
        """boolean_op : expression MINUS expression"""
        p[0] = BooleanOp(
            left=p[1],
            right=p[3],
            operation='difference',
            line=p.lineno(2),
            column=0
        )
    
    def p_boolean_op_intersection(self, p):
        """boolean_op : expression AMPERSAND expression"""
        p[0] = BooleanOp(
            left=p[1],
            right=p[3],
            operation='intersection',
            line=p.lineno(2),
            column=0
        )
    
    def p_params(self, p):
        """params : param_list
                 | empty"""
        p[0] = p[1] if p[1] is not None else {}
    
    def p_param_list(self, p):
        """param_list : param_list COMMA param
                     | param"""
        if len(p) == 4:
            p[0] = {**p[1], **p[3]}
        else:
            p[0] = p[1]
    
    def p_param(self, p):
        """param : IDENTIFIER EQUALS value"""
        p[0] = {p[1]: p[3]}
    
    def p_value_number(self, p):
        """value : NUMBER"""
        p[0] = p[1]
    
    def p_value_vector(self, p):
        """value : vector"""
        p[0] = p[1]
    
    def p_value_string(self, p):
        """value : STRING"""
        p[0] = p[1]
    
    def p_vector(self, p):
        """vector : LBRACKET number_list RBRACKET"""
        p[0] = p[2]
    
    def p_number_list(self, p):
        """number_list : number_list COMMA NUMBER
                      | NUMBER"""
        if len(p) == 4:
            p[0] = p[1] + [p[3]]
        else:
            p[0] = [p[1]]
    
    def p_empty(self, p):
        """empty :"""
        pass
    
    def p_error(self, p):
        """Handle parsing errors."""
        if p:
            raise ParseError(
                f"Syntax error: unexpected token '{p.value}'",
                line=p.lineno,
                column=0
            )
        else:
            raise ParseError("Syntax error: unexpected end of input")
    
    def parse(self, code: str) -> Result[List[ASTNode], ParseError]:
        """
        Parse Shape Code and generate AST.
        
        Args:
            code: Shape Code source string
            
        Returns:
            Result containing list of AST nodes or ParseError
        """
        try:
            # Tokenize
            tokens = self.lexer.tokenize(code)
            
            # Build parser if not already built
            if self.parser is None:
                self.parser = yacc.yacc(module=self, debug=False, write_tables=False)
            
            # Parse
            self.ast = self.parser.parse(code, lexer=self.lexer.lexer)
            
            if self.ast is None:
                self.ast = []
            
            return Result.Ok(self.ast)
            
        except ParseError as e:
            return Result.Err(e)
        except SyntaxError as e:
            return Result.Err(ParseError(str(e)))
        except Exception as e:
            return Result.Err(ParseError(f"Unexpected error during parsing: {str(e)}"))
    
    def validate(self, ast: List[ASTNode]) -> Result[None, ValidationError]:
        """
        Validate the semantic correctness of an AST.
        
        Args:
            ast: List of AST nodes to validate
            
        Returns:
            Result indicating success or containing ValidationError
        """
        from src.validator import Validator
        validator = Validator()
        return validator.validate(ast)
