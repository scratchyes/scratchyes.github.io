"""Geometry engine for creating and manipulating 3D shapes."""

import numpy as np
import trimesh
from typing import List, Optional
from src.errors import GeometryError
from src.result import Result


class GeometryEngine:
    """Engine for creating and manipulating 3D geometric shapes."""
    
    def create_cube(self, size: List[float]) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Create a cube mesh.
        
        Args:
            size: List of [width, height, depth]
            
        Returns:
            Result containing trimesh or GeometryError
        """
        try:
            if len(size) != 3:
                return Result.Err(GeometryError(f"Size must have 3 values, got {len(size)}"))
            
            if any(s <= 0 for s in size):
                return Result.Err(GeometryError("All size values must be positive"))
            
            # Create box centered at origin
            mesh = trimesh.creation.box(extents=size)
            return Result.Ok(mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to create cube: {str(e)}"))
    
    def create_sphere(
        self, 
        radius: float, 
        subdivisions: int = 3
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Create a sphere mesh.
        
        Args:
            radius: Sphere radius
            subdivisions: Number of subdivisions (higher = smoother)
            
        Returns:
            Result containing trimesh or GeometryError
        """
        try:
            if radius <= 0:
                return Result.Err(GeometryError(f"Radius must be positive, got {radius}"))
            
            if subdivisions < 0:
                return Result.Err(GeometryError(f"Subdivisions must be non-negative, got {subdivisions}"))
            
            # Create icosphere
            mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
            return Result.Ok(mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to create sphere: {str(e)}"))
    
    def create_cylinder(
        self, 
        radius: float, 
        height: float,
        segments: int = 32
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Create a cylinder mesh.
        
        Args:
            radius: Cylinder radius
            height: Cylinder height
            segments: Number of segments around circumference
            
        Returns:
            Result containing trimesh or GeometryError
        """
        try:
            if radius <= 0:
                return Result.Err(GeometryError(f"Radius must be positive, got {radius}"))
            
            if height <= 0:
                return Result.Err(GeometryError(f"Height must be positive, got {height}"))
            
            if segments < 3:
                return Result.Err(GeometryError(f"Segments must be at least 3, got {segments}"))
            
            # Create cylinder centered at origin
            mesh = trimesh.creation.cylinder(
                radius=radius,
                height=height,
                sections=segments
            )
            return Result.Ok(mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to create cylinder: {str(e)}"))
    
    def create_cone(
        self, 
        radius: float, 
        height: float,
        segments: int = 32
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Create a cone mesh.
        
        Args:
            radius: Cone base radius
            height: Cone height
            segments: Number of segments around circumference
            
        Returns:
            Result containing trimesh or GeometryError
        """
        try:
            if radius <= 0:
                return Result.Err(GeometryError(f"Radius must be positive, got {radius}"))
            
            if height <= 0:
                return Result.Err(GeometryError(f"Height must be positive, got {height}"))
            
            if segments < 3:
                return Result.Err(GeometryError(f"Segments must be at least 3, got {segments}"))
            
            # Create cone centered at origin
            mesh = trimesh.creation.cone(
                radius=radius,
                height=height,
                sections=segments
            )
            return Result.Ok(mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to create cone: {str(e)}"))
    
    def translate(
        self, 
        mesh: trimesh.Trimesh, 
        offset: List[float]
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Translate a mesh.
        
        Args:
            mesh: Input mesh
            offset: Translation vector [x, y, z]
            
        Returns:
            Result containing translated mesh or GeometryError
        """
        try:
            if len(offset) != 3:
                return Result.Err(GeometryError(f"Offset must have 3 values, got {len(offset)}"))
            
            # Create a copy and translate
            result_mesh = mesh.copy()
            result_mesh.apply_translation(offset)
            return Result.Ok(result_mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to translate mesh: {str(e)}"))
    
    def rotate(
        self, 
        mesh: trimesh.Trimesh, 
        angles: List[float]
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Rotate a mesh using Euler angles.
        
        Args:
            mesh: Input mesh
            angles: Rotation angles in degrees [x, y, z]
            
        Returns:
            Result containing rotated mesh or GeometryError
        """
        try:
            if len(angles) != 3:
                return Result.Err(GeometryError(f"Angles must have 3 values, got {len(angles)}"))
            
            # Create a copy
            result_mesh = mesh.copy()
            
            # Convert degrees to radians and apply rotations
            angles_rad = np.radians(angles)
            
            # Rotation around X axis
            if angles_rad[0] != 0:
                matrix = trimesh.transformations.rotation_matrix(
                    angles_rad[0], [1, 0, 0]
                )
                result_mesh.apply_transform(matrix)
            
            # Rotation around Y axis
            if angles_rad[1] != 0:
                matrix = trimesh.transformations.rotation_matrix(
                    angles_rad[1], [0, 1, 0]
                )
                result_mesh.apply_transform(matrix)
            
            # Rotation around Z axis
            if angles_rad[2] != 0:
                matrix = trimesh.transformations.rotation_matrix(
                    angles_rad[2], [0, 0, 1]
                )
                result_mesh.apply_transform(matrix)
            
            return Result.Ok(result_mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to rotate mesh: {str(e)}"))
    
    def scale(
        self, 
        mesh: trimesh.Trimesh, 
        factors: List[float]
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Scale a mesh.
        
        Args:
            mesh: Input mesh
            factors: Scale factors [x, y, z]
            
        Returns:
            Result containing scaled mesh or GeometryError
        """
        try:
            if len(factors) != 3:
                return Result.Err(GeometryError(f"Factors must have 3 values, got {len(factors)}"))
            
            if any(f <= 0 for f in factors):
                return Result.Err(GeometryError("All scale factors must be positive"))
            
            # Create a copy and scale
            result_mesh = mesh.copy()
            
            # Create scale matrix
            scale_matrix = np.eye(4)
            scale_matrix[0, 0] = factors[0]
            scale_matrix[1, 1] = factors[1]
            scale_matrix[2, 2] = factors[2]
            
            result_mesh.apply_transform(scale_matrix)
            return Result.Ok(result_mesh)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to scale mesh: {str(e)}"))
    
    def union(
        self, 
        mesh1: trimesh.Trimesh, 
        mesh2: trimesh.Trimesh
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Compute the union of two meshes.
        
        Args:
            mesh1: First mesh
            mesh2: Second mesh
            
        Returns:
            Result containing union mesh or GeometryError
        """
        try:
            result = mesh1.union(mesh2, engine='blender')
            if result is None or not isinstance(result, trimesh.Trimesh):
                # Fallback: just combine the meshes
                result = trimesh.util.concatenate([mesh1, mesh2])
            return Result.Ok(result)
            
        except Exception as e:
            # Fallback: concatenate meshes
            try:
                result = trimesh.util.concatenate([mesh1, mesh2])
                return Result.Ok(result)
            except Exception as e2:
                return Result.Err(GeometryError(f"Failed to compute union: {str(e)}"))
    
    def difference(
        self, 
        mesh1: trimesh.Trimesh, 
        mesh2: trimesh.Trimesh
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Compute the difference of two meshes (mesh1 - mesh2).
        
        Args:
            mesh1: Base mesh
            mesh2: Mesh to subtract
            
        Returns:
            Result containing difference mesh or GeometryError
        """
        try:
            result = mesh1.difference(mesh2, engine='blender')
            if result is None or not isinstance(result, trimesh.Trimesh):
                return Result.Err(GeometryError("Boolean difference operation failed"))
            return Result.Ok(result)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to compute difference: {str(e)}"))
    
    def intersection(
        self, 
        mesh1: trimesh.Trimesh, 
        mesh2: trimesh.Trimesh
    ) -> Result[trimesh.Trimesh, GeometryError]:
        """
        Compute the intersection of two meshes.
        
        Args:
            mesh1: First mesh
            mesh2: Second mesh
            
        Returns:
            Result containing intersection mesh or GeometryError
        """
        try:
            result = mesh1.intersection(mesh2, engine='blender')
            if result is None or not isinstance(result, trimesh.Trimesh):
                return Result.Err(GeometryError("Boolean intersection operation failed"))
            return Result.Ok(result)
            
        except Exception as e:
            return Result.Err(GeometryError(f"Failed to compute intersection: {str(e)}"))
