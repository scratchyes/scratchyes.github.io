"""Compiler for converting Shape Code AST to 3D meshes."""

import trimesh
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from src.ast_nodes import (
    ASTNode, Primitive, Transform, BooleanOp,
    Assignment, Identifier, Export
)
from src.geometry import GeometryEngine
from src.errors import CompileError
from src.result import Result


@dataclass
class CompilerOptions:
    """Options for compilation."""
    resolution: str = 'medium'  # 'low', 'medium', 'high'
    optimize: bool = True
    max_vertices: int = 1_000_000  # Maximum vertices in output mesh
    max_faces: int = 1_000_000  # Maximum faces in output mesh
    max_ast_nodes: int = 1000  # Maximum AST nodes to prevent DoS
    
    def get_subdivisions(self) -> int:
        """Get sphere subdivisions based on resolution."""
        return {'low': 2, 'medium': 3, 'high': 4}[self.resolution]
    
    def get_segments(self) -> int:
        """Get cylinder/cone segments based on resolution."""
        return {'low': 16, 'medium': 32, 'high': 64}[self.resolution]


@dataclass
class CompilationResult:
    """Result of compilation."""
    mesh: Optional[trimesh.Trimesh]
    vertex_count: int
    face_count: int
    exports: List[str]
    
    def __repr__(self) -> str:
        return (f"CompilationResult(vertices={self.vertex_count}, "
                f"faces={self.face_count}, exports={len(self.exports)})")


class Compiler:
    """Compiler for Shape Code AST."""
    
    def __init__(self, options: Optional[CompilerOptions] = None):
        """
        Initialize the compiler.
        
        Args:
            options: Compilation options
        """
        self.options = options or CompilerOptions()
        self.engine = GeometryEngine()
        self.symbol_table: Dict[str, trimesh.Trimesh] = {}
        self.exports: List[str] = []
    
    def compile(self, ast: List[ASTNode]) -> Result[CompilationResult, CompileError]:
        """
        Compile AST to 3D mesh.
        
        Args:
            ast: List of AST nodes
            
        Returns:
            Result containing CompilationResult or CompileError
        """
        # Security check: limit AST size
        if len(ast) > self.options.max_ast_nodes:
            return Result.Err(CompileError(
                f"AST too large ({len(ast)} nodes, max {self.options.max_ast_nodes})"
            ))
        
        self.symbol_table = {}
        self.exports = []
        
        try:
            final_mesh = None
            
            for node in ast:
                result = self._compile_node(node)
                if result.is_err():
                    return Result.Err(result.unwrap_err())
                
                # If this is an export node, track it
                if isinstance(node, Export):
                    mesh = result.unwrap()
                    if mesh is not None:
                        final_mesh = mesh
            
            # Calculate statistics
            vertex_count = 0
            face_count = 0
            
            if final_mesh is not None:
                vertex_count = len(final_mesh.vertices)
                face_count = len(final_mesh.faces)
                
                # Security check: limit mesh size
                if vertex_count > self.options.max_vertices:
                    return Result.Err(CompileError(
                        f"Mesh too large ({vertex_count} vertices, max {self.options.max_vertices})"
                    ))
                
                if face_count > self.options.max_faces:
                    return Result.Err(CompileError(
                        f"Mesh too large ({face_count} faces, max {self.options.max_faces})"
                    ))
            
            compilation_result = CompilationResult(
                mesh=final_mesh,
                vertex_count=vertex_count,
                face_count=face_count,
                exports=self.exports
            )
            
            return Result.Ok(compilation_result)
            
        except Exception as e:
            return Result.Err(CompileError(f"Compilation failed: {str(e)}"))
    
    def _compile_node(self, node: ASTNode) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile a single AST node."""
        if isinstance(node, Assignment):
            return self._compile_assignment(node)
        elif isinstance(node, Export):
            return self._compile_export(node)
        elif isinstance(node, Primitive):
            return self._compile_primitive(node)
        elif isinstance(node, Transform):
            return self._compile_transform(node)
        elif isinstance(node, BooleanOp):
            return self._compile_boolean_op(node)
        elif isinstance(node, Identifier):
            return self._compile_identifier(node)
        else:
            return Result.Err(CompileError(f"Unknown node type: {type(node).__name__}"))
    
    def _compile_assignment(self, node: Assignment) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile an assignment statement."""
        result = self._compile_node(node.expression)
        if result.is_err():
            return result
        
        mesh = result.unwrap()
        if mesh is not None:
            self.symbol_table[node.identifier] = mesh
        
        return Result.Ok(None)
    
    def _compile_export(self, node: Export) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile an export statement."""
        result = self._compile_node(node.expression)
        if result.is_err():
            return result
        
        mesh = result.unwrap()
        if mesh is not None:
            self.exports.append(node.filepath)
        
        return Result.Ok(mesh)
    
    def _compile_primitive(self, node: Primitive) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile a primitive shape."""
        shape_type = node.shape_type
        params = node.params
        
        try:
            if shape_type == 'cube':
                size = params.get('size')
                if size is None:
                    return Result.Err(CompileError("Cube requires 'size' parameter", node.line))
                result = self.engine.create_cube(size)
                
            elif shape_type == 'sphere':
                radius = params.get('radius')
                if radius is None:
                    return Result.Err(CompileError("Sphere requires 'radius' parameter", node.line))
                subdivisions = params.get('subdivisions', self.options.get_subdivisions())
                result = self.engine.create_sphere(radius, subdivisions)
                
            elif shape_type == 'cylinder':
                radius = params.get('radius')
                height = params.get('height')
                if radius is None or height is None:
                    return Result.Err(CompileError("Cylinder requires 'radius' and 'height' parameters", node.line))
                segments = params.get('segments', self.options.get_segments())
                result = self.engine.create_cylinder(radius, height, segments)
                
            elif shape_type == 'cone':
                radius = params.get('radius')
                height = params.get('height')
                if radius is None or height is None:
                    return Result.Err(CompileError("Cone requires 'radius' and 'height' parameters", node.line))
                segments = params.get('segments', self.options.get_segments())
                result = self.engine.create_cone(radius, height, segments)
                
            else:
                return Result.Err(CompileError(f"Unknown primitive type: {shape_type}", node.line))
            
            if result.is_err():
                error = result.unwrap_err()
                return Result.Err(CompileError(str(error), node.line))
            
            return Result.Ok(result.unwrap())
            
        except Exception as e:
            return Result.Err(CompileError(f"Failed to create {shape_type}: {str(e)}", node.line))
    
    def _compile_transform(self, node: Transform) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile a transform operation."""
        # Compile the target
        target_result = self._compile_node(node.target)
        if target_result.is_err():
            return target_result
        
        mesh = target_result.unwrap()
        if mesh is None:
            return Result.Err(CompileError("Transform target is None", node.line))
        
        # Apply transformation
        transform_type = node.transform_type
        params = node.params
        
        try:
            if transform_type == 'translate':
                result = self.engine.translate(mesh, params)
            elif transform_type == 'rotate':
                result = self.engine.rotate(mesh, params)
            elif transform_type == 'scale':
                result = self.engine.scale(mesh, params)
            else:
                return Result.Err(CompileError(f"Unknown transform type: {transform_type}", node.line))
            
            if result.is_err():
                error = result.unwrap_err()
                return Result.Err(CompileError(str(error), node.line))
            
            return Result.Ok(result.unwrap())
            
        except Exception as e:
            return Result.Err(CompileError(f"Failed to apply {transform_type}: {str(e)}", node.line))
    
    def _compile_boolean_op(self, node: BooleanOp) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile a boolean operation."""
        # Compile left operand
        left_result = self._compile_node(node.left)
        if left_result.is_err():
            return left_result
        
        left_mesh = left_result.unwrap()
        if left_mesh is None:
            return Result.Err(CompileError("Boolean left operand is None", node.line))
        
        # Compile right operand
        right_result = self._compile_node(node.right)
        if right_result.is_err():
            return right_result
        
        right_mesh = right_result.unwrap()
        if right_mesh is None:
            return Result.Err(CompileError("Boolean right operand is None", node.line))
        
        # Apply boolean operation
        operation = node.operation
        
        try:
            if operation == 'union':
                result = self.engine.union(left_mesh, right_mesh)
            elif operation == 'difference':
                result = self.engine.difference(left_mesh, right_mesh)
            elif operation == 'intersection':
                result = self.engine.intersection(left_mesh, right_mesh)
            else:
                return Result.Err(CompileError(f"Unknown boolean operation: {operation}", node.line))
            
            if result.is_err():
                error = result.unwrap_err()
                return Result.Err(CompileError(str(error), node.line))
            
            return Result.Ok(result.unwrap())
            
        except Exception as e:
            return Result.Err(CompileError(f"Failed to apply {operation}: {str(e)}", node.line))
    
    def _compile_identifier(self, node: Identifier) -> Result[Optional[trimesh.Trimesh], CompileError]:
        """Compile an identifier reference."""
        if node.name not in self.symbol_table:
            return Result.Err(CompileError(f"Undefined variable: {node.name}", node.line))
        
        return Result.Ok(self.symbol_table[node.name])
    
    def export_stl(self, mesh: trimesh.Trimesh, filepath: str) -> Result[None, CompileError]:
        """
        Export mesh to STL format.
        
        Args:
            mesh: Mesh to export
            filepath: Output file path
            
        Returns:
            Result indicating success or CompileError
        """
        try:
            mesh.export(filepath, file_type='stl')
            return Result.Ok(None)
        except Exception as e:
            return Result.Err(CompileError(f"Failed to export STL: {str(e)}"))
    
    def export_obj(self, mesh: trimesh.Trimesh, filepath: str) -> Result[None, CompileError]:
        """
        Export mesh to OBJ format.
        
        Args:
            mesh: Mesh to export
            filepath: Output file path
            
        Returns:
            Result indicating success or CompileError
        """
        try:
            mesh.export(filepath, file_type='obj')
            return Result.Ok(None)
        except Exception as e:
            return Result.Err(CompileError(f"Failed to export OBJ: {str(e)}"))
    
    def optimize_mesh(self, mesh: trimesh.Trimesh) -> Result[trimesh.Trimesh, CompileError]:
        """
        Optimize mesh by removing duplicate vertices and degenerate faces.
        
        Args:
            mesh: Mesh to optimize
            
        Returns:
            Result containing optimized mesh or CompileError
        """
        try:
            optimized = mesh.copy()
            optimized.merge_vertices()
            optimized.remove_degenerate_faces()
            optimized.remove_duplicate_faces()
            return Result.Ok(optimized)
        except Exception as e:
            return Result.Err(CompileError(f"Failed to optimize mesh: {str(e)}"))
    
    def estimate_export_size(self, mesh: trimesh.Trimesh, format: str = 'stl') -> int:
        """
        Estimate export file size in bytes.
        
        Args:
            mesh: Mesh to estimate
            format: Export format ('stl' or 'obj')
            
        Returns:
            Estimated file size in bytes
        """
        if format == 'stl':
            # STL binary: 80 byte header + 4 bytes count + 50 bytes per triangle
            return 84 + (len(mesh.faces) * 50)
        elif format == 'obj':
            # OBJ text: rough estimate
            vertex_size = len(mesh.vertices) * 30  # ~30 chars per vertex line
            face_size = len(mesh.faces) * 20  # ~20 chars per face line
            return vertex_size + face_size
        else:
            return 0
