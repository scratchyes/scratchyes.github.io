"""Shape Code - A domain-specific language for 3D modeling."""

__version__ = "0.1.0"

from src.lexer import Lexer, Token
from src.parser import Parser
from src.validator import Validator
from src.ast_nodes import (
    ASTNode,
    Primitive,
    Transform,
    BooleanOp,
    Assignment,
    Identifier,
    Export,
)
from src.errors import (
    ShapeCodeError,
    ParseError,
    ValidationError,
    CompileError,
    GeometryError,
    NLProcessError,
)
from src.result import Result
from src.geometry import GeometryEngine
from src.compiler import Compiler, CompilerOptions, CompilationResult
from src.file_manager import FileManager
from src.nl_processor import NLProcessor

__all__ = [
    "Lexer",
    "Token",
    "Parser",
    "Validator",
    "ASTNode",
    "Primitive",
    "Transform",
    "BooleanOp",
    "Assignment",
    "Identifier",
    "Export",
    "ShapeCodeError",
    "ParseError",
    "ValidationError",
    "CompileError",
    "GeometryError",
    "NLProcessError",
    "Result",
    "GeometryEngine",
    "Compiler",
    "CompilerOptions",
    "CompilationResult",
    "FileManager",
    "NLProcessor",
]
