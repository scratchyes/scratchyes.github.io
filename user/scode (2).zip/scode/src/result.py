"""Result type for error handling."""

from typing import TypeVar, Generic, Union, Callable


T = TypeVar('T')
E = TypeVar('E')


class Result(Generic[T, E]):
    """
    A Result type that represents either success (Ok) or failure (Err).
    
    This provides a functional approach to error handling without exceptions.
    """
    
    def __init__(self, value: Union[T, E], is_ok: bool):
        self._value = value
        self._is_ok = is_ok
    
    @staticmethod
    def Ok(value: T) -> 'Result[T, E]':
        """Create a successful Result."""
        return Result(value, True)
    
    @staticmethod
    def Err(error: E) -> 'Result[T, E]':
        """Create a failed Result."""
        return Result(error, False)
    
    def is_ok(self) -> bool:
        """Check if the Result is Ok."""
        return self._is_ok
    
    def is_err(self) -> bool:
        """Check if the Result is Err."""
        return not self._is_ok
    
    def unwrap(self) -> T:
        """
        Get the Ok value or raise an exception if Err.
        
        Raises:
            ValueError: If the Result is Err
        """
        if self._is_ok:
            return self._value
        raise ValueError(f"Called unwrap on an Err value: {self._value}")
    
    def unwrap_or(self, default: T) -> T:
        """Get the Ok value or return a default if Err."""
        if self._is_ok:
            return self._value
        return default
    
    def unwrap_err(self) -> E:
        """
        Get the Err value or raise an exception if Ok.
        
        Raises:
            ValueError: If the Result is Ok
        """
        if not self._is_ok:
            return self._value
        raise ValueError(f"Called unwrap_err on an Ok value: {self._value}")
    
    def map(self, func: Callable[[T], 'U']) -> 'Result[U, E]':
        """
        Apply a function to the Ok value if present.
        
        Args:
            func: Function to apply to the Ok value
            
        Returns:
            Result with the transformed value or the original Err
        """
        if self._is_ok:
            return Result.Ok(func(self._value))
        return Result.Err(self._value)
    
    def map_err(self, func: Callable[[E], 'F']) -> 'Result[T, F]':
        """
        Apply a function to the Err value if present.
        
        Args:
            func: Function to apply to the Err value
            
        Returns:
            Result with the transformed error or the original Ok
        """
        if not self._is_ok:
            return Result.Err(func(self._value))
        return Result.Ok(self._value)
    
    def and_then(self, func: Callable[[T], 'Result[U, E]']) -> 'Result[U, E]':
        """
        Chain Result-returning operations.
        
        Args:
            func: Function that takes the Ok value and returns a new Result
            
        Returns:
            The Result from func if Ok, otherwise the original Err
        """
        if self._is_ok:
            return func(self._value)
        return Result.Err(self._value)
    
    def __repr__(self) -> str:
        if self._is_ok:
            return f"Result.Ok({self._value!r})"
        return f"Result.Err({self._value!r})"
