# Shape Code 构建说明

## 开发环境设置

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 运行应用

#### GUI 模式
```bash
python main.py
```

#### CLI 模式
```bash
python main.py --cli examples/shapecode/basic/cube.shapecode -o output.stl
```

或直接使用 CLI 工具：
```bash
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o output.stl
```

## 打包为可执行文件

### 使用 PyInstaller

1. 安装 PyInstaller：
```bash
pip install pyinstaller
```

2. 构建可执行文件：
```bash
pyinstaller shapecode.spec
```

3. 可执行文件位置：
- Windows: `dist/ShapeCode.exe`
- Linux/Mac: `dist/ShapeCode`

### 构建选项

#### 单文件模式（已配置）
当前配置使用 `--onefile` 模式，生成单个可执行文件。

#### 调试模式
如果需要查看控制台输出，编辑 `shapecode.spec`：
```python
console=True,  # 改为 True
```

#### 包含图标
如果有应用图标，在 `shapecode.spec` 中添加：
```python
exe = EXE(
    ...
    icon='assets/icon.ico',  # Windows
    ...
)
```

## 测试打包后的应用

### Windows
```bash
dist\ShapeCode.exe
```

### Linux/Mac
```bash
./dist/ShapeCode
```

## 常见问题

### 1. 缺少模块错误
如果打包后运行时提示缺少模块，在 `shapecode.spec` 的 `hiddenimports` 中添加：
```python
hiddenimports=[
    'missing_module_name',
    ...
],
```

### 2. 示例文件未包含
确保 `examples/shapecode/` 目录存在且包含 `.shapecode` 文件。

### 3. PyQt6 相关错误
确保安装了完整的 PyQt6：
```bash
pip install PyQt6
```

### 4. trimesh 相关错误
某些 trimesh 功能可能需要额外的依赖：
```bash
pip install rtree shapely
```

## 分发

### Windows
1. 将 `dist/ShapeCode.exe` 分发给用户
2. 用户无需安装 Python 即可运行

### Linux
1. 将 `dist/ShapeCode` 分发给用户
2. 确保文件有执行权限：`chmod +x ShapeCode`

### Mac
1. 将 `dist/ShapeCode` 分发给用户
2. 可能需要在系统偏好设置中允许运行

## 创建安装程序（可选）

### Windows - Inno Setup

1. 安装 Inno Setup: https://jrsoftware.org/isinfo.php

2. 创建 `installer.iss` 文件：
```iss
[Setup]
AppName=Shape Code
AppVersion=0.1.0
DefaultDirName={pf}\ShapeCode
DefaultGroupName=Shape Code
OutputDir=installer
OutputBaseFilename=ShapeCodeSetup

[Files]
Source: "dist\ShapeCode.exe"; DestDir: "{app}"
Source: "examples\*"; DestDir: "{app}\examples"; Flags: recursesubdirs

[Icons]
Name: "{group}\Shape Code"; Filename: "{app}\ShapeCode.exe"
Name: "{commondesktop}\Shape Code"; Filename: "{app}\ShapeCode.exe"
```

3. 编译安装程序：
```bash
iscc installer.iss
```

### Linux - AppImage

使用 `appimage-builder` 创建 AppImage：
```bash
pip install appimage-builder
appimage-builder --recipe appimage.yml
```

### Mac - DMG

使用 `create-dmg` 创建 DMG 安装包：
```bash
brew install create-dmg
create-dmg dist/ShapeCode.app
```

## 持续集成

可以使用 GitHub Actions 自动构建：

```yaml
name: Build

on: [push]

jobs:
  build:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [windows-latest, ubuntu-latest, macos-latest]
    
    steps:
    - uses: actions/checkout@v2
    - uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    - run: pip install -r requirements.txt
    - run: pip install pyinstaller
    - run: pyinstaller shapecode.spec
    - uses: actions/upload-artifact@v2
      with:
        name: ShapeCode-${{ matrix.os }}
        path: dist/
```

## 版本发布

1. 更新版本号：
   - `main.py` 中的 `version`
   - `pyproject.toml` 中的 `version`
   - `src/__init__.py` 中的 `__version__`

2. 创建 Git 标签：
```bash
git tag v0.1.0
git push origin v0.1.0
```

3. 构建并上传发布包到 GitHub Releases
