# 修复 PyInstaller 在 Linux 上的问题

## 🔴 问题

```
ERROR: Python was built without a shared library, which is required by PyInstaller.
```

## 📋 原因

你的 Python 是通过 pyenv 安装的，但没有启用共享库支持。PyInstaller 需要共享库才能工作。

## ✅ 解决方案

### 方案 1: 重新安装 Python（推荐）

使用 pyenv 重新安装 Python，启用共享库：

```bash
# 1. 设置环境变量
export PYTHON_CONFIGURE_OPTS="--enable-shared"

# 2. 重新安装 Python 3.11.1
pyenv install 3.11.1

# 3. 设置为全局版本
pyenv global 3.11.1

# 4. 验证
python --version

# 5. 重新安装 PyInstaller
pip install pyinstaller

# 6. 尝试构建
python build_exe.py
```

### 方案 2: 使用系统 Python

如果系统有 Python，可以使用系统版本：

```bash
# 1. 检查系统 Python
which python3
python3 --version

# 2. 使用系统 Python
python3 -m pip install pyinstaller

# 3. 构建
python3 build_exe.py
```

### 方案 3: 使用 Docker（最简单）

创建一个 Docker 容器来构建：

```bash
# 1. 创建 Dockerfile
cat > Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app
COPY . /app

RUN pip install -r requirements.txt
RUN pip install pyinstaller

CMD ["python", "build_exe.py"]
EOF

# 2. 构建镜像
docker build -t shapecode-builder .

# 3. 运行构建
docker run -v $(pwd)/dist:/app/dist shapecode-builder
```

### 方案 4: 不构建可执行文件（最快）

直接使用 Python 运行应用：

```bash
# 安装依赖
pip install -r requirements.txt

# 运行 CLI
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl

# 运行 GUI（需要 X11）
python main.py
```

## 🎯 推荐方案

### 对于 Linux 服务器（无 GUI）

**使用方案 4** - 直接运行 Python 代码：

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 测试 CLI
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o test.stl

# 3. 检查输出
ls -lh test.stl
```

### 对于 Linux 桌面

**使用方案 1** - 重新安装 Python：

```bash
export PYTHON_CONFIGURE_OPTS="--enable-shared"
pyenv install 3.11.1 --force
pyenv global 3.11.1
pip install pyinstaller
python build_exe.py
```

## 📝 验证 Python 共享库

检查 Python 是否有共享库：

```bash
# 方法 1
python -c "import sysconfig; print(sysconfig.get_config_var('LIBDIR'))"

# 方法 2
ldd $(which python) | grep libpython

# 方法 3
find $(python -c "import sys; print(sys.prefix)") -name "libpython*.so*"
```

如果找到 `libpython3.11.so` 之类的文件，说明有共享库。

## 🔧 快速测试

不构建可执行文件，直接测试应用：

```bash
# 1. 安装依赖
pip install ply trimesh numpy

# 2. 测试解析器
python examples/parser_demo.py

# 3. 测试 CLI
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl

# 4. 检查生成的文件
ls -lh cube.stl
file cube.stl
```

## 💡 为什么会这样？

- **pyenv 默认行为**: pyenv 默认不启用共享库，以减小体积
- **PyInstaller 需求**: PyInstaller 需要共享库来打包应用
- **解决方法**: 重新编译 Python 或使用已有共享库的 Python

## 🎯 最佳实践

### 开发环境
```bash
# 直接运行 Python 代码
python main.py
python shapecode_cli.py input.shapecode -o output.stl
```

### 生产环境
```bash
# 使用 Docker 打包
docker build -t shapecode .
docker run shapecode
```

### 分发给用户
- **Linux**: 提供 Python 代码 + requirements.txt
- **Windows**: 在 Windows 上构建 .exe
- **macOS**: 在 macOS 上构建 .app

## 📊 各方案对比

| 方案 | 难度 | 时间 | 推荐度 |
|------|------|------|--------|
| 重新安装 Python | 中 | 10-20分钟 | ⭐⭐⭐ |
| 使用系统 Python | 低 | 5分钟 | ⭐⭐⭐⭐ |
| 使用 Docker | 中 | 15分钟 | ⭐⭐⭐⭐⭐ |
| 直接运行代码 | 低 | 1分钟 | ⭐⭐⭐⭐⭐ |

## ✨ 立即可用的方案

**最快的方式 - 直接运行**:

```bash
# 1. 安装核心依赖
pip install ply trimesh numpy

# 2. 测试应用
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl

# 3. 查看结果
ls -lh cube.stl
```

这样你可以立即使用 Shape Code，无需构建可执行文件！

## 🔄 如果一定要构建可执行文件

在 **Windows** 或 **macOS** 上构建会更容易：

- **Windows**: 下载官方 Python 安装包，自带共享库
- **macOS**: 使用 Homebrew 安装的 Python，自带共享库

Linux 上构建可执行文件比较复杂，通常不推荐。

---

**建议**: 在 Linux 上直接运行 Python 代码，在 Windows 上构建 .exe 文件。
