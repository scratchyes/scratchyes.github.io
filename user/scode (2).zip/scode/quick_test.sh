#!/bin/bash
# Shape Code 快速测试脚本（Linux）

echo "========================================"
echo "Shape Code 快速测试"
echo "========================================"
echo

# 检查 Python
echo "[1/4] 检查 Python..."
python --version
if [ $? -ne 0 ]; then
    echo "错误: Python 未找到"
    exit 1
fi
echo

# 安装核心依赖
echo "[2/4] 安装核心依赖..."
pip install ply trimesh numpy --quiet
echo "✓ 核心依赖已安装"
echo

# 测试解析器
echo "[3/4] 测试解析器..."
python examples/parser_demo.py
if [ $? -eq 0 ]; then
    echo "✓ 解析器测试通过"
else
    echo "✗ 解析器测试失败"
fi
echo

# 测试 CLI
echo "[4/4] 测试 CLI 工具..."
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o test_cube.stl
if [ $? -eq 0 ] && [ -f test_cube.stl ]; then
    echo "✓ CLI 测试通过"
    echo "  生成文件: test_cube.stl"
    ls -lh test_cube.stl
else
    echo "✗ CLI 测试失败"
fi
echo

echo "========================================"
echo "测试完成！"
echo "========================================"
echo
echo "Shape Code 可以正常使用！"
echo
echo "使用方法:"
echo "  python shapecode_cli.py input.shapecode -o output.stl"
echo "  python main.py  # GUI 模式（需要 X11）"
echo
