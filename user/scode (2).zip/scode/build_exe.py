#!/usr/bin/env python3
"""构建 Windows 可执行文件的 Python 脚本"""

import subprocess
import sys
import os
from pathlib import Path

def main():
    print("=" * 70)
    print("Shape Code Windows 可执行文件构建")
    print("=" * 70)
    print()
    
    # 检查 PyInstaller
    print("[1/3] 检查 PyInstaller...")
    try:
        import PyInstaller
        print(f"  ✓ PyInstaller 已安装 (版本 {PyInstaller.__version__})")
    except ImportError:
        print("  PyInstaller 未安装，正在安装...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
            print("  ✓ PyInstaller 安装成功")
        except subprocess.CalledProcessError:
            print("  ✗ PyInstaller 安装失败")
            return 1
    
    # 检查配置文件
    print("\n[2/3] 检查配置文件...")
    if not Path("shapecode.spec").exists():
        print("  ✗ 未找到 shapecode.spec")
        return 1
    print("  ✓ 配置文件存在")
    
    # 开始构建
    print("\n[3/3] 开始构建可执行文件...")
    print("  这可能需要几分钟时间，请耐心等待...")
    print("  构建过程中会显示详细输出...\n")
    print("-" * 70)
    
    try:
        # 运行 PyInstaller，实时显示输出
        process = subprocess.Popen(
            [sys.executable, "-m", "PyInstaller", "shapecode.spec", "--clean"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # 实时打印输出
        for line in process.stdout:
            print(line, end='')
        
        # 等待进程完成
        process.wait()
        
        print("-" * 70)
        
        if process.returncode == 0:
            print("\n  ✓ 构建成功！")
            
            # 检查输出文件
            exe_path = Path("dist/ShapeCode.exe")
            if exe_path.exists():
                size_mb = exe_path.stat().st_size / (1024 * 1024)
                print(f"\n  可执行文件位置: {exe_path}")
                print(f"  文件大小: {size_mb:.1f} MB")
                print("\n  你可以:")
                print(f"    1. 直接运行: {exe_path}")
                print("    2. 分发给其他用户（无需安装 Python）")
                print("    3. 创建快捷方式到桌面")
            else:
                print("\n  ⚠ 警告: 未找到可执行文件")
                print("  构建可能未完全成功")
        else:
            print("\n  ✗ 构建失败")
            print(f"  返回码: {process.returncode}")
            return 1
            
    except Exception as e:
        print(f"  ✗ 构建过程出错: {e}")
        return 1
    
    print("\n" + "=" * 70)
    print("构建完成！")
    print("=" * 70)
    return 0

if __name__ == "__main__":
    sys.exit(main())
