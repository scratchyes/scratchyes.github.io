# Shape Code 在 Linux 上的使用指南

## 🐧 当前情况

你在 **Linux** 系统上，Python 通过 pyenv 安装。

**问题**: PyInstaller 需要 Python 共享库，但你的 Python 没有编译共享库支持。

**解决方案**: 在 Linux 上，推荐直接运行 Python 代码，而不是构建可执行文件。

## ✅ 推荐使用方式

### 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 运行快速测试
chmod +x quick_test.sh
./quick_test.sh
```

### CLI 模式（命令行）

```bash
# 基本用法
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl

# 指定格式
python shapecode_cli.py input.shapecode -o output.obj -f obj

# 指定分辨率
python shapecode_cli.py input.shapecode -o output.stl -r high

# 详细输出
python shapecode_cli.py input.shapecode -o output.stl -v
```

### GUI 模式（需要 X11）

```bash
# 安装 GUI 依赖
pip install PyQt6

# 运行 GUI
python main.py
```

**注意**: 如果你在远程服务器上，GUI 可能无法使用。

## 📦 安装依赖

### 最小依赖（仅 CLI）

```bash
pip install ply trimesh numpy
```

### 完整依赖（包括 GUI 和 AI）

```bash
pip install -r requirements.txt
```

### 可选依赖

```bash
# GUI 支持
pip install PyQt6

# AI 代码生成
pip install openai

# 3D 预览
pip install pyvista
```

## 🎯 使用示例

### 示例 1: 编译基本形状

```bash
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl
python shapecode_cli.py examples/shapecode/basic/sphere.shapecode -o sphere.stl
```

### 示例 2: 编译复杂形状

```bash
python shapecode_cli.py examples/shapecode/complex/house.shapecode -o house.stl
python shapecode_cli.py examples/shapecode/complex/snowman.shapecode -o snowman.stl
```

### 示例 3: 批量处理

```bash
# 处理所有示例
for file in examples/shapecode/*/*.shapecode; do
    output=$(basename "$file" .shapecode).stl
    python shapecode_cli.py "$file" -o "$output"
    echo "生成: $output"
done
```

### 示例 4: 使用 Python API

```python
from src.parser import Parser
from src.compiler import Compiler

# 读取 Shape Code
with open('input.shapecode', 'r') as f:
    code = f.read()

# 解析
parser = Parser()
result = parser.parse(code)

if result.is_ok():
    ast = result.unwrap()
    
    # 验证
    if parser.validate(ast).is_ok():
        # 编译
        compiler = Compiler()
        compile_result = compiler.compile(ast)
        
        if compile_result.is_ok():
            mesh_result = compile_result.unwrap()
            # 导出
            compiler.export_stl(mesh_result.mesh, 'output.stl')
            print(f"成功! 顶点: {mesh_result.vertex_count}, 面: {mesh_result.face_count}")
```

## 🔧 故障排除

### 问题 1: 缺少依赖

```bash
# 错误: ModuleNotFoundError: No module named 'ply'
pip install ply

# 错误: ModuleNotFoundError: No module named 'trimesh'
pip install trimesh

# 错误: ModuleNotFoundError: No module named 'numpy'
pip install numpy
```

### 问题 2: PyQt6 无法安装

```bash
# 如果 PyQt6 安装失败，可以不安装（只影响 GUI）
# CLI 模式不需要 PyQt6
python shapecode_cli.py input.shapecode -o output.stl
```

### 问题 3: 权限问题

```bash
# 使用 --user 标志
pip install --user -r requirements.txt
```

## 🚀 性能优化

### 使用虚拟环境

```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt

# 使用应用
python shapecode_cli.py input.shapecode -o output.stl

# 退出虚拟环境
deactivate
```

### 批量处理优化

```python
# batch_process.py
from src.parser import Parser
from src.compiler import Compiler
import glob

parser = Parser()
compiler = Compiler()

for shapecode_file in glob.glob('examples/shapecode/*/*.shapecode'):
    with open(shapecode_file, 'r') as f:
        code = f.read()
    
    result = parser.parse(code)
    if result.is_ok():
        ast = result.unwrap()
        if parser.validate(ast).is_ok():
            compile_result = compiler.compile(ast)
            if compile_result.is_ok():
                output = shapecode_file.replace('.shapecode', '.stl')
                compiler.export_stl(compile_result.unwrap().mesh, output)
                print(f"✓ {output}")
```

## 📊 系统要求

- **Python**: 3.8+
- **内存**: 至少 512 MB
- **磁盘**: 至少 100 MB
- **CPU**: 任何现代 CPU

## 🎓 学习资源

### 查看示例

```bash
# 列出所有示例
find examples/shapecode -name "*.shapecode"

# 查看示例内容
cat examples/shapecode/basic/cube.shapecode
cat examples/shapecode/complex/house.shapecode
```

### 运行演示

```bash
# 解析器演示
python examples/parser_demo.py

# 测试套件
python -m pytest tests/ -v
```

## 🔄 与 Windows 的区别

| 功能 | Linux | Windows |
|------|-------|---------|
| CLI 模式 | ✅ 完全支持 | ✅ 完全支持 |
| GUI 模式 | ⚠️ 需要 X11 | ✅ 原生支持 |
| 可执行文件 | ❌ 需要共享库 | ✅ 容易构建 |
| 性能 | ✅ 通常更快 | ✅ 良好 |

## 💡 最佳实践

### 开发环境

```bash
# 使用虚拟环境
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 生产环境

```bash
# 使用 Docker
docker build -t shapecode .
docker run -v $(pwd)/data:/data shapecode python shapecode_cli.py /data/input.shapecode -o /data/output.stl
```

### 服务器部署

```bash
# 创建服务脚本
cat > /usr/local/bin/shapecode << 'EOF'
#!/bin/bash
cd /opt/shapecode
python shapecode_cli.py "$@"
EOF

chmod +x /usr/local/bin/shapecode

# 使用
shapecode input.shapecode -o output.stl
```

## ✨ 总结

在 Linux 上使用 Shape Code：

1. **推荐方式**: 直接运行 Python 代码
2. **安装依赖**: `pip install -r requirements.txt`
3. **CLI 模式**: `python shapecode_cli.py input.shapecode -o output.stl`
4. **GUI 模式**: `python main.py`（需要 X11）
5. **不推荐**: 构建可执行文件（需要重新编译 Python）

**Shape Code 在 Linux 上完全可用，只是使用方式略有不同！** 🐧🚀

---

**快速测试**: 运行 `./quick_test.sh` 立即开始使用！
