# Assets

This directory contains application assets such as icons and images.
