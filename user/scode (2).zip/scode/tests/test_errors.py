"""Tests for error type hierarchy."""

import pytest
from src.errors import (
    ShapeCodeError,
    ParseError,
    ValidationError,
    CompileError,
    GeometryError,
    NLProcessError,
)


def test_base_error_without_location():
    """Test ShapeCodeError without line/column information."""
    error = ShapeCodeError("Test error")
    assert error.message == "Test error"
    assert error.line is None
    assert error.column is None
    assert str(error) == "Test error"


def test_base_error_with_line():
    """Test ShapeCodeError with line number."""
    error = ShapeCodeError("Test error", line=5)
    assert error.message == "Test error"
    assert error.line == 5
    assert error.column is None
    assert str(error) == "Line 5: Test error"


def test_base_error_with_line_and_column():
    """Test ShapeCodeError with line and column."""
    error = ShapeCodeError("Test error", line=5, column=12)
    assert error.message == "Test error"
    assert error.line == 5
    assert error.column == 12
    assert str(error) == "Line 5, Column 12: Test error"


def test_parse_error():
    """Test ParseError inherits from ShapeCodeError."""
    error = ParseError("Syntax error", line=3, column=8)
    assert isinstance(error, ShapeCodeError)
    assert error.message == "Syntax error"
    assert str(error) == "Line 3, Column 8: Syntax error"


def test_validation_error():
    """Test ValidationError inherits from ShapeCodeError."""
    error = ValidationError("Undefined variable")
    assert isinstance(error, ShapeCodeError)


def test_compile_error():
    """Test CompileError inherits from ShapeCodeError."""
    error = CompileError("Compilation failed")
    assert isinstance(error, ShapeCodeError)


def test_geometry_error():
    """Test GeometryError inherits from ShapeCodeError."""
    error = GeometryError("Invalid boolean operation")
    assert isinstance(error, ShapeCodeError)


def test_nl_process_error():
    """Test NLProcessError inherits from ShapeCodeError."""
    error = NLProcessError("API request failed")
    assert isinstance(error, ShapeCodeError)
