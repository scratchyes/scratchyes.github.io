"""Tests for the Shape Code parser."""

import pytest
from src.parser import Parser
from src.ast_nodes import (
    Assignment, Primitive, Transform, BooleanOp, 
    Identifier, Export
)


def test_parser_simple_assignment():
    """Test parsing a simple assignment."""
    parser = Parser()
    code = "cube = Cube(size=[10, 10, 10])"
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert len(ast) == 1
    assert isinstance(ast[0], Assignment)
    assert ast[0].identifier == 'cube'
    assert isinstance(ast[0].expression, Primitive)
    assert ast[0].expression.shape_type == 'cube'


def test_parser_all_primitives():
    """Test parsing all primitive shapes."""
    parser = Parser()
    
    # Cube
    result = parser.parse("c = Cube(size=[10, 10, 10])")
    assert result.is_ok()
    ast = result.unwrap()
    assert ast[0].expression.shape_type == 'cube'
    
    # Sphere
    result = parser.parse("s = Sphere(radius=5)")
    assert result.is_ok()
    ast = result.unwrap()
    assert ast[0].expression.shape_type == 'sphere'
    
    # Cylinder
    result = parser.parse("cy = Cylinder(radius=3, height=10)")
    assert result.is_ok()
    ast = result.unwrap()
    assert ast[0].expression.shape_type == 'cylinder'
    
    # Cone
    result = parser.parse("co = Cone(radius=4, height=8)")
    assert result.is_ok()
    ast = result.unwrap()
    assert ast[0].expression.shape_type == 'cone'


def test_parser_transform():
    """Test parsing transform operations."""
    parser = Parser()
    code = "translated = cube.translate([5, 0, 0])"
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert len(ast) == 1
    assert isinstance(ast[0], Assignment)
    assert isinstance(ast[0].expression, Transform)
    assert ast[0].expression.transform_type == 'translate'
    assert ast[0].expression.params == [5, 0, 0]


def test_parser_chained_transforms():
    """Test parsing chained transformations."""
    parser = Parser()
    code = "result = cube.translate([1, 2, 3]).rotate([0, 0, 45])"
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[0].expression, Transform)
    assert ast[0].expression.transform_type == 'rotate'
    assert isinstance(ast[0].expression.target, Transform)
    assert ast[0].expression.target.transform_type == 'translate'


def test_parser_boolean_operations():
    """Test parsing boolean operations."""
    parser = Parser()
    
    # Union
    result = parser.parse("union_shape = cube + sphere")
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[0].expression, BooleanOp)
    assert ast[0].expression.operation == 'union'
    
    # Difference
    result = parser.parse("diff_shape = cube - sphere")
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[0].expression, BooleanOp)
    assert ast[0].expression.operation == 'difference'
    
    # Intersection
    result = parser.parse("inter_shape = cube & sphere")
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[0].expression, BooleanOp)
    assert ast[0].expression.operation == 'intersection'


def test_parser_complex_expression():
    """Test parsing complex nested expressions."""
    parser = Parser()
    code = "complex = (Cube(size=[20, 20, 20]) - Sphere(radius=12)).translate([0, 0, 10])"
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[0].expression, Transform)
    assert isinstance(ast[0].expression.target, BooleanOp)


def test_parser_export():
    """Test parsing export statements."""
    parser = Parser()
    code = 'export(cube, "output.stl")'
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert len(ast) == 1
    assert isinstance(ast[0], Export)
    assert ast[0].filepath == "output.stl"


def test_parser_multiple_statements():
    """Test parsing multiple statements."""
    parser = Parser()
    code = """
cube = Cube(size=[10, 10, 10])
sphere = Sphere(radius=5)
result = cube + sphere
export(result, "output.stl")
"""
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert len(ast) == 4
    assert isinstance(ast[0], Assignment)
    assert isinstance(ast[1], Assignment)
    assert isinstance(ast[2], Assignment)
    assert isinstance(ast[3], Export)


def test_parser_identifier_reference():
    """Test parsing variable references."""
    parser = Parser()
    code = """
cube = Cube(size=[10, 10, 10])
translated = cube.translate([5, 0, 0])
"""
    result = parser.parse(code)
    
    assert result.is_ok()
    ast = result.unwrap()
    assert isinstance(ast[1].expression, Transform)
    assert isinstance(ast[1].expression.target, Identifier)
    assert ast[1].expression.target.name == 'cube'


def test_parser_error_handling():
    """Test parser error handling."""
    parser = Parser()
    
    # Invalid syntax
    result = parser.parse("cube = ")
    assert result.is_err()
    
    # Unexpected token
    result = parser.parse("cube = Cube(size=[10, 10, 10]")
    assert result.is_err()
