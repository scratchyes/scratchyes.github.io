"""Tests for the Shape Code lexer."""

import pytest
from src.lexer import Lexer, Token


def test_lexer_basic_tokens():
    """Test basic token recognition."""
    lexer = Lexer()
    code = "cube = Cube(size=[10, 20, 30])"
    tokens = lexer.tokenize(code)
    
    assert len(tokens) > 0
    assert tokens[0].type == 'IDENTIFIER'
    assert tokens[0].value == 'cube'
    assert tokens[1].type == 'EQUALS'
    assert tokens[2].type == 'CUBE'


def test_lexer_numbers():
    """Test number tokenization."""
    lexer = Lexer()
    code = "123 45.67"
    tokens = lexer.tokenize(code)
    
    assert len(tokens) == 2
    assert tokens[0].type == 'NUMBER'
    assert tokens[0].value == 123
    assert tokens[1].type == 'NUMBER'
    assert tokens[1].value == 45.67


def test_lexer_strings():
    """Test string tokenization."""
    lexer = Lexer()
    code = '"output.stl"'
    tokens = lexer.tokenize(code)
    
    assert len(tokens) == 1
    assert tokens[0].type == 'STRING'
    assert tokens[0].value == 'output.stl'


def test_lexer_comments():
    """Test comment handling."""
    lexer = Lexer()
    code = "# This is a comment\ncube = Cube(size=[10, 10, 10])"
    tokens = lexer.tokenize(code)
    
    # Comments should be ignored
    assert tokens[0].type == 'IDENTIFIER'
    assert tokens[0].value == 'cube'


def test_lexer_line_tracking():
    """Test line number tracking."""
    lexer = Lexer()
    code = "cube = Cube(size=[10, 10, 10])\nsphere = Sphere(radius=5)"
    tokens = lexer.tokenize(code)
    
    # First line tokens
    assert tokens[0].line == 1
    
    # Find first token on second line
    sphere_token = next(t for t in tokens if t.value == 'sphere')
    assert sphere_token.line == 2


def test_lexer_operators():
    """Test operator tokenization."""
    lexer = Lexer()
    code = "result = cube + sphere - cylinder & cone"
    tokens = lexer.tokenize(code)
    
    token_types = [t.type for t in tokens]
    assert 'PLUS' in token_types
    assert 'MINUS' in token_types
    assert 'AMPERSAND' in token_types


def test_lexer_transforms():
    """Test transform method tokenization."""
    lexer = Lexer()
    code = "cube.translate([1, 2, 3]).rotate([0, 0, 45])"
    tokens = lexer.tokenize(code)
    
    token_types = [t.type for t in tokens]
    assert 'DOT' in token_types
    assert 'TRANSLATE' in token_types
    assert 'ROTATE' in token_types
