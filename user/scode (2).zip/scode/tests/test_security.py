"""Security tests for Shape Code."""

import pytest
import tempfile
import os
from pathlib import Path

from src.file_manager import FileManager
from src.compiler import Compiler, CompilerOptions
from src.parser import Parser


def test_path_traversal_prevention():
    """Test that path traversal attacks are prevented."""
    file_manager = FileManager()
    
    # Test path traversal attempts
    dangerous_paths = [
        "../../../etc/passwd",
        "..\\..\\..\\windows\\system32\\config\\sam",
        "/etc/passwd",
        "C:\\Windows\\System32\\config\\sam"
    ]
    
    for dangerous_path in dangerous_paths:
        result = file_manager.load_shapecode(dangerous_path)
        assert result.is_err(), f"Should reject dangerous path: {dangerous_path}"


def test_file_size_limit():
    """Test that large files are rejected."""
    file_manager = FileManager()
    
    # Create a large content (>10MB)
    large_content = "x" * (11 * 1024 * 1024)
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.shapecode', delete=False) as f:
        temp_path = f.name
        f.write(large_content)
    
    try:
        result = file_manager.load_shapecode(temp_path)
        assert result.is_err(), "Should reject large files"
        assert "too large" in str(result.unwrap_err()).lower()
    finally:
        os.unlink(temp_path)


def test_invalid_file_extension():
    """Test that invalid file extensions are rejected."""
    file_manager = FileManager()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.exe', delete=False) as f:
        temp_path = f.name
        f.write("malicious content")
    
    try:
        result = file_manager.save_shapecode("test", temp_path)
        assert result.is_err(), "Should reject invalid extensions"
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def test_ast_size_limit():
    """Test that large ASTs are rejected."""
    parser = Parser()
    compiler = Compiler(CompilerOptions(max_ast_nodes=10))
    
    # Create code with many statements
    code = "\n".join([f"cube{i} = Cube(size=[10, 10, 10])" for i in range(20)])
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    compile_result = compiler.compile(ast)
    
    assert compile_result.is_err(), "Should reject large AST"
    assert "too large" in str(compile_result.unwrap_err()).lower()


def test_mesh_size_limit():
    """Test that large meshes are rejected."""
    parser = Parser()
    compiler = Compiler(CompilerOptions(
        max_vertices=100,
        max_faces=100,
        resolution='high'
    ))
    
    # Create code that generates a large mesh
    code = "sphere = Sphere(radius=100)\nexport(sphere, 'test.stl')"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    compile_result = compiler.compile(ast)
    
    # Should either succeed with small mesh or fail with size limit
    if compile_result.is_ok():
        result = compile_result.unwrap()
        assert result.vertex_count <= 100 or result.face_count <= 100


def test_no_code_injection():
    """Test that Shape Code cannot execute arbitrary Python code."""
    parser = Parser()
    
    # Attempt code injection
    malicious_codes = [
        "import os; os.system('rm -rf /')",
        "eval('print(1)')",
        "exec('import sys')",
        "__import__('os').system('ls')"
    ]
    
    for code in malicious_codes:
        result = parser.parse(code)
        # Should either fail to parse or be safely handled
        assert result.is_err(), f"Should reject malicious code: {code}"


def test_safe_error_messages():
    """Test that error messages don't leak sensitive information."""
    file_manager = FileManager()
    
    # Try to load non-existent file
    result = file_manager.load_shapecode("/nonexistent/path/file.shapecode")
    
    assert result.is_err()
    error_msg = str(result.unwrap_err())
    
    # Error message should not contain full system paths
    assert "/home/" not in error_msg.lower() or "c:\\" not in error_msg.lower()


def test_api_key_not_in_errors():
    """Test that API keys are not exposed in error messages."""
    from src.nl_processor import NLProcessor
    
    # Create processor with fake key
    processor = NLProcessor(api_key="sk-fake-key-for-testing")
    
    # Try to process (will fail)
    result = processor.process("test")
    
    if result.is_err():
        error_msg = str(result.unwrap_err())
        # API key should not appear in error message
        assert "sk-fake-key" not in error_msg


def test_content_size_limit():
    """Test that large content is rejected when saving."""
    file_manager = FileManager()
    
    # Create large content
    large_content = "x" * (11 * 1024 * 1024)
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.shapecode', delete=False) as f:
        temp_path = f.name
    
    try:
        result = file_manager.save_shapecode(large_content, temp_path)
        assert result.is_err(), "Should reject large content"
        assert "too large" in str(result.unwrap_err()).lower()
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def test_safe_file_operations():
    """Test that file operations are safe."""
    file_manager = FileManager()
    
    # Test with safe path
    with tempfile.TemporaryDirectory() as tmpdir:
        safe_path = os.path.join(tmpdir, "test.shapecode")
        content = "cube = Cube(size=[10, 10, 10])"
        
        # Save should succeed
        save_result = file_manager.save_shapecode(content, safe_path)
        assert save_result.is_ok()
        
        # Load should succeed
        load_result = file_manager.load_shapecode(safe_path)
        assert load_result.is_ok()
        assert load_result.unwrap() == content


def test_resource_limits_in_options():
    """Test that compiler options enforce resource limits."""
    options = CompilerOptions(
        max_vertices=1000,
        max_faces=1000,
        max_ast_nodes=100
    )
    
    assert options.max_vertices == 1000
    assert options.max_faces == 1000
    assert options.max_ast_nodes == 100
