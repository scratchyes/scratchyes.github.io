"""Tests for Result type."""

import pytest
from src.result import Result


def test_ok_creation():
    """Test creating an Ok Result."""
    result = Result.Ok(42)
    assert result.is_ok()
    assert not result.is_err()
    assert result.unwrap() == 42


def test_err_creation():
    """Test creating an Err Result."""
    result = Result.Err("error message")
    assert result.is_err()
    assert not result.is_ok()
    assert result.unwrap_err() == "error message"


def test_unwrap_on_err_raises():
    """Test that unwrap raises on Err."""
    result = Result.Err("error")
    with pytest.raises(ValueError, match="Called unwrap on an Err value"):
        result.unwrap()


def test_unwrap_err_on_ok_raises():
    """Test that unwrap_err raises on Ok."""
    result = Result.Ok(42)
    with pytest.raises(ValueError, match="Called unwrap_err on an Ok value"):
        result.unwrap_err()


def test_unwrap_or():
    """Test unwrap_or returns value or default."""
    ok_result = Result.Ok(42)
    err_result = Result.Err("error")
    
    assert ok_result.unwrap_or(0) == 42
    assert err_result.unwrap_or(0) == 0


def test_map_on_ok():
    """Test map transforms Ok value."""
    result = Result.Ok(5)
    mapped = result.map(lambda x: x * 2)
    
    assert mapped.is_ok()
    assert mapped.unwrap() == 10


def test_map_on_err():
    """Test map preserves Err."""
    result = Result.Err("error")
    mapped = result.map(lambda x: x * 2)
    
    assert mapped.is_err()
    assert mapped.unwrap_err() == "error"


def test_map_err_on_err():
    """Test map_err transforms Err value."""
    result = Result.Err("error")
    mapped = result.map_err(lambda e: e.upper())
    
    assert mapped.is_err()
    assert mapped.unwrap_err() == "ERROR"


def test_map_err_on_ok():
    """Test map_err preserves Ok."""
    result = Result.Ok(42)
    mapped = result.map_err(lambda e: e.upper())
    
    assert mapped.is_ok()
    assert mapped.unwrap() == 42


def test_and_then_on_ok():
    """Test and_then chains operations."""
    result = Result.Ok(5)
    chained = result.and_then(lambda x: Result.Ok(x * 2))
    
    assert chained.is_ok()
    assert chained.unwrap() == 10


def test_and_then_on_err():
    """Test and_then preserves Err."""
    result = Result.Err("error")
    chained = result.and_then(lambda x: Result.Ok(x * 2))
    
    assert chained.is_err()
    assert chained.unwrap_err() == "error"


def test_and_then_propagates_err():
    """Test and_then propagates Err from chained operation."""
    result = Result.Ok(5)
    chained = result.and_then(lambda x: Result.Err("chained error"))
    
    assert chained.is_err()
    assert chained.unwrap_err() == "chained error"


def test_result_repr():
    """Test Result string representation."""
    ok_result = Result.Ok(42)
    err_result = Result.Err("error")
    
    assert repr(ok_result) == "Result.Ok(42)"
    assert repr(err_result) == "Result.Err('error')"
