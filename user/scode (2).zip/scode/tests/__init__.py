"""Tests for Shape Code system."""
