"""Tests for the Shape Code validator."""

import pytest
from src.parser import Parser
from src.validator import Validator
from src.errors import ValidationError


def test_validator_valid_code():
    """Test validation of valid Shape Code."""
    parser = Parser()
    validator = Validator()
    
    code = """
cube = Cube(size=[10, 10, 10])
sphere = Sphere(radius=5)
result = cube + sphere
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_ok()


def test_validator_undefined_variable():
    """Test detection of undefined variable."""
    parser = Parser()
    validator = Validator()
    
    code = "result = undefined_var + sphere"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "Undefined variable" in str(error)


def test_validator_missing_required_param():
    """Test detection of missing required parameters."""
    parser = Parser()
    validator = Validator()
    
    # Cube without size
    code = "cube = Cube()"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "Missing required parameter" in str(error)


def test_validator_invalid_param():
    """Test detection of invalid parameters."""
    parser = Parser()
    validator = Validator()
    
    code = "cube = Cube(size=[10, 10, 10], invalid_param=5)"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "Invalid parameter" in str(error)


def test_validator_invalid_size_format():
    """Test detection of invalid size format."""
    parser = Parser()
    validator = Validator()
    
    # Size with wrong number of values
    code = "cube = Cube(size=[10, 10])"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "exactly 3 values" in str(error)


def test_validator_negative_values():
    """Test detection of negative values."""
    parser = Parser()
    validator = Validator()
    
    # Negative radius
    code = "sphere = Sphere(radius=-5)"
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "must be positive" in str(error)


def test_validator_invalid_transform_params():
    """Test detection of invalid transform parameters."""
    parser = Parser()
    validator = Validator()
    
    # Transform with wrong number of values
    code = """
cube = Cube(size=[10, 10, 10])
result = cube.translate([5, 0])
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "exactly 3 values" in str(error)


def test_validator_invalid_scale():
    """Test detection of invalid scale factors."""
    parser = Parser()
    validator = Validator()
    
    # Negative scale factor
    code = """
cube = Cube(size=[10, 10, 10])
result = cube.scale([1, -1, 1])
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "must be positive" in str(error)


def test_validator_invalid_export():
    """Test detection of invalid export statements."""
    parser = Parser()
    validator = Validator()
    
    # Invalid file extension
    code = """
cube = Cube(size=[10, 10, 10])
export(cube, "output.txt")
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_err()
    error = validate_result.unwrap_err()
    assert "Invalid file extension" in str(error)


def test_validator_all_primitives():
    """Test validation of all primitive types."""
    parser = Parser()
    validator = Validator()
    
    code = """
cube = Cube(size=[10, 10, 10])
sphere = Sphere(radius=5)
cylinder = Cylinder(radius=3, height=10)
cone = Cone(radius=4, height=8)
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_ok()


def test_validator_complex_expression():
    """Test validation of complex expressions."""
    parser = Parser()
    validator = Validator()
    
    code = """
cube = Cube(size=[20, 20, 20])
sphere = Sphere(radius=12)
difference = cube - sphere
result = difference.translate([0, 0, 10])
export(result, "output.stl")
"""
    
    parse_result = parser.parse(code)
    assert parse_result.is_ok()
    
    ast = parse_result.unwrap()
    validate_result = validator.validate(ast)
    assert validate_result.is_ok()
