# 构建 Shape Code 可执行文件

## 说明

目前项目中只有构建配置文件（`shapecode.spec`），还没有实际的可执行文件。

要生成可执行文件，请按照以下步骤操作：

## 构建步骤

### 方法 1: 使用构建脚本（推荐）

**Windows:**
```bash
build.bat
```

**Linux/Mac:**
```bash
chmod +x build.sh
./build.sh
```

构建脚本会自动：
- 检查并安装 PyInstaller
- 检查依赖
- 构建可执行文件
- 验证构建结果

### 方法 2: 手动构建

**1. 安装 PyInstaller**
```bash
python -m pip install pyinstaller
```

**2. 构建可执行文件**
```bash
pyinstaller shapecode.spec
```

或者使用 Python 模块方式：
```bash
python -m PyInstaller shapecode.spec
```

### 3. 查找可执行文件

构建完成后，可执行文件将位于：

**Windows:**
```
dist/ShapeCode.exe
```

**Linux/Mac:**
```
dist/ShapeCode
```

## 快速测试（不构建可执行文件）

如果你只是想测试应用，不需要构建可执行文件，可以直接运行：

### 命令行模式
```bash
python shapecode_cli.py examples/shapecode/basic/cube.shapecode -o cube.stl
```

### GUI 模式（需要 PyQt6）
```bash
python main.py
```

### 安装 GUI 依赖
```bash
python -m pip install PyQt6
```

## 构建时间

首次构建可能需要几分钟时间，因为 PyInstaller 需要：
1. 分析所有依赖
2. 收集所有需要的文件
3. 打包成单个可执行文件

## 构建后的文件大小

预计可执行文件大小：
- Windows: 约 50-100 MB
- Linux: 约 40-80 MB
- Mac: 约 50-100 MB

（大小取决于包含的依赖库）

## 故障排除

### 问题 1: PyInstaller 未找到
```bash
# 确保 PyInstaller 已安装
python -m pip list | findstr pyinstaller
```

### 问题 2: 缺少模块
如果构建后运行时提示缺少模块，编辑 `shapecode.spec` 文件，在 `hiddenimports` 中添加缺失的模块。

### 问题 3: 示例文件未包含
确保 `examples/shapecode/` 目录存在且包含 `.shapecode` 文件。

## 分发

构建完成后，你可以：

1. **直接分发可执行文件**
   - 将 `dist/ShapeCode.exe` 发送给用户
   - 用户无需安装 Python 即可运行

2. **创建安装程序**（可选）
   - Windows: 使用 Inno Setup
   - 参考 `build_instructions.md` 了解详情

## 当前状态

✅ 配置文件已创建：`shapecode.spec`
✅ 构建说明已提供：`build_instructions.md`
⏳ 可执行文件需要手动构建

## 为什么没有预构建的可执行文件？

1. **文件大小**: 可执行文件通常很大（50-100 MB），不适合包含在源代码中
2. **平台差异**: 需要为每个平台（Windows/Linux/Mac）分别构建
3. **依赖更新**: 当依赖更新时，需要重新构建
4. **开发灵活性**: 开发时直接运行 Python 代码更方便

## 推荐使用方式

**开发/测试阶段:**
```bash
python main.py
```

**最终用户分发:**
```bash
pyinstaller shapecode.spec
# 然后分发 dist/ShapeCode.exe
```
