# Shape Code

Shape Code 是一个用于 3D 建模的领域特定语言（DSL），结合了自然语言处理和代码生成功能。

## 特性

- 🎨 **简洁的语法** - 易于学习和使用的 3D 建模语言
- 🤖 **AI 驱动** - 使用自然语言描述生成 Shape Code
- 🔧 **强大的功能** - 支持基本形状、变换和布尔运算
- 📦 **多格式导出** - 支持 STL 和 OBJ 格式
- ✅ **完整验证** - 语法和语义验证，提供详细错误信息

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt

# 如果需要 GUI 界面
pip install PyQt6
```

> **注意**: 项目目前以源代码形式提供。如需可执行文件，请参考 [BUILD_EXECUTABLE.md](BUILD_EXECUTABLE.md) 了解如何构建。

### 基本用法

#### 1. 编写 Shape Code

创建一个文件 `example.shapecode`:

```shapecode
# 创建一个立方体
cube = Cube(size=[10, 10, 10])

# 创建一个球体
sphere = Sphere(radius=7)

# 组合它们
result = cube + sphere

# 导出
export(result, "output.stl")
```

#### 2. 使用命令行工具编译

```bash
python shapecode_cli.py example.shapecode -o output.stl
```

#### 3. 使用 Python API

```python
from src.parser import Parser
from src.compiler import Compiler

# 解析 Shape Code
parser = Parser()
code = """
cube = Cube(size=[10, 10, 10])
export(cube, "cube.stl")
"""

result = parser.parse(code)
if result.is_ok():
    ast = result.unwrap()
    
    # 编译为 3D 网格
    compiler = Compiler()
    compile_result = compiler.compile(ast)
    
    if compile_result.is_ok():
        mesh_result = compile_result.unwrap()
        # 导出
        compiler.export_stl(mesh_result.mesh, "cube.stl")
```

## Shape Code 语法

### 基本形状

```shapecode
# 立方体
cube = Cube(size=[10, 10, 10])

# 球体
sphere = Sphere(radius=5)

# 圆柱体
cylinder = Cylinder(radius=3, height=10)

# 圆锥体
cone = Cone(radius=4, height=8)
```

### 变换操作

```shapecode
# 平移
moved = cube.translate([5, 0, 0])

# 旋转（度数）
rotated = cube.rotate([0, 0, 45])

# 缩放
scaled = cube.scale([2, 1, 1])

# 链式变换
result = cube.translate([1, 2, 3]).rotate([0, 0, 45]).scale([2, 2, 2])
```

### 布尔运算

```shapecode
# 并集（组合）
union = cube + sphere

# 差集（减去）
difference = cube - sphere

# 交集（重叠部分）
intersection = cube & sphere
```

### 导出

```shapecode
# 导出为 STL
export(result, "output.stl")

# 导出为 OBJ
export(result, "output.obj")
```

## 示例

查看 `examples/shapecode/` 目录获取更多示例：

- **basic/** - 基本形状示例
- **transforms/** - 变换操作示例
- **boolean/** - 布尔运算示例
- **complex/** - 复杂形状示例

### 示例：雪人

```shapecode
# 底部球体
bottom = Sphere(radius=8)

# 中间球体
middle = Sphere(radius=6)
middle_positioned = middle.translate([0, 0, 12])

# 头部球体
head = Sphere(radius=4)
head_positioned = head.translate([0, 0, 20])

# 组合所有部分
snowman = bottom + middle_positioned + head_positioned

export(snowman, "snowman.stl")
```

## 自然语言生成

使用 AI 从自然语言生成 Shape Code：

```python
from src.nl_processor import NLProcessor

# 需要设置 OPENAI_API_KEY 环境变量
processor = NLProcessor()

result = processor.process("创建一个带有球形孔的立方体")
if result.is_ok():
    shape_code = result.unwrap()
    print(shape_code)
```

## 命令行选项

```bash
python shapecode_cli.py [选项] 输入文件

选项:
  -o, --output PATH       输出文件路径（默认: output.stl）
  -f, --format FORMAT     输出格式: stl 或 obj（默认: stl）
  -r, --resolution RES    网格分辨率: low, medium, high（默认: medium）
  --no-optimize          禁用网格优化
  -v, --verbose          详细输出
```

## 架构

```
Shape Code 系统架构:

自然语言 → NLProcessor → Shape Code
                              ↓
                          Lexer → Tokens
                              ↓
                          Parser → AST
                              ↓
                         Validator
                              ↓
                         Compiler → 3D Mesh
                              ↓
                      Export (STL/OBJ)
```

## 核心组件

- **Lexer** (`src/lexer.py`) - 词法分析器
- **Parser** (`src/parser.py`) - 语法分析器
- **Validator** (`src/validator.py`) - 语义验证器
- **GeometryEngine** (`src/geometry.py`) - 几何引擎
- **Compiler** (`src/compiler.py`) - 编译器
- **FileManager** (`src/file_manager.py`) - 文件管理器
- **NLProcessor** (`src/nl_processor.py`) - 自然语言处理器

## 测试

运行测试套件：

```bash
# 运行所有测试
python -m pytest tests/

# 运行特定测试
python -m pytest tests/test_parser.py -v

# 查看解析器演示
python examples/parser_demo.py
```

## 开发状态

### ✅ 已完成
- 词法和语法解析器
- 语义验证器
- 几何引擎（形状、变换、布尔运算）
- 编译器（AST 到网格）
- 文件管理系统
- 示例库
- 自然语言处理
- STL/OBJ 导出
- 命令行工具

### 🚧 进行中
- GUI 界面（PyQt6）
- 3D 实时预览（PyVista）
- 交互式编辑器

## 技术栈

- **Python** 3.8+
- **PLY** - 词法和语法分析
- **trimesh** - 3D 几何处理
- **numpy** - 数值计算
- **OpenAI** - 自然语言处理
- **PyQt6** - GUI 框架（待实现）
- **PyVista** - 3D 可视化（待实现）

## 许可证

MIT License

## 贡献

欢迎贡献！请查看 `IMPLEMENTATION_SUMMARY.md` 了解项目状态和待办事项。

## 文档

- `PARSER_IMPLEMENTATION.md` - 解析器实现详情
- `IMPLEMENTATION_SUMMARY.md` - 完整实现总结
- `examples/` - 示例代码
