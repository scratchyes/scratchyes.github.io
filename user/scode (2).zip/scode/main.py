#!/usr/bin/env python3
"""
Shape Code - 3D Modeling DSL
Main application entry point.
"""

import sys
import argparse
from pathlib import Path

# Check if GUI dependencies are available
try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import Qt
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False
    print("Warning: PyQt6 not installed. GUI mode not available.")
    print("Install with: pip install PyQt6")

from src.file_manager import FileManager


def run_cli(args):
    """Run in CLI mode."""
    from shapecode_cli import main as cli_main
    # Reconstruct sys.argv for CLI
    sys.argv = ['shapecode_cli.py', args.input]
    if args.output:
        sys.argv.extend(['-o', args.output])
    if args.format:
        sys.argv.extend(['-f', args.format])
    if args.resolution:
        sys.argv.extend(['-r', args.resolution])
    if args.no_optimize:
        sys.argv.append('--no-optimize')
    if args.verbose:
        sys.argv.append('-v')
    
    return cli_main()


def run_gui(args):
    """Run in GUI mode."""
    if not GUI_AVAILABLE:
        print("Error: PyQt6 is required for GUI mode.")
        print("Install with: pip install PyQt6")
        return 1
    
    try:
        from gui.main_window import MainWindow
    except ImportError:
        print("Error: GUI components not yet implemented.")
        print("Use CLI mode with: python main.py --cli <file>")
        return 1
    
    # Create application
    app = QApplication(sys.argv)
    app.setApplicationName("Shape Code")
    app.setOrganizationName("ShapeCode")
    
    # Load preferences
    file_manager = FileManager()
    prefs_result = file_manager.load_preferences()
    preferences = prefs_result.unwrap() if prefs_result.is_ok() else {}
    
    # Create and show main window
    window = MainWindow(preferences)
    
    # Load file if specified
    if args.input:
        window.load_file(args.input)
    
    window.show()
    
    return app.exec()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Shape Code - A domain-specific language for 3D modeling',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Launch GUI
  python main.py
  
  # Open file in GUI
  python main.py mymodel.shapecode
  
  # CLI mode
  python main.py --cli input.shapecode -o output.stl
  
  # Show version
  python main.py --version
"""
    )
    
    parser.add_argument(
        'input',
        nargs='?',
        help='Input Shape Code file (optional in GUI mode, required in CLI mode)'
    )
    
    parser.add_argument(
        '--cli',
        action='store_true',
        help='Run in CLI mode (no GUI)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='Shape Code 0.1.0'
    )
    
    # CLI-specific options
    cli_group = parser.add_argument_group('CLI options')
    cli_group.add_argument(
        '-o', '--output',
        help='Output file path (CLI mode only)'
    )
    cli_group.add_argument(
        '-f', '--format',
        choices=['stl', 'obj'],
        help='Output format (CLI mode only)'
    )
    cli_group.add_argument(
        '-r', '--resolution',
        choices=['low', 'medium', 'high'],
        help='Mesh resolution (CLI mode only)'
    )
    cli_group.add_argument(
        '--no-optimize',
        action='store_true',
        help='Disable mesh optimization (CLI mode only)'
    )
    cli_group.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Verbose output (CLI mode only)'
    )
    
    args = parser.parse_args()
    
    # Determine mode
    if args.cli or not GUI_AVAILABLE:
        # CLI mode
        if not args.input:
            parser.error("Input file required in CLI mode")
        return run_cli(args)
    else:
        # GUI mode
        return run_gui(args)


if __name__ == '__main__':
    sys.exit(main())
