# Shape Code 快速开始指南

## 🚀 构建 Windows 可执行文件

### 方法 1: 使用 Python 脚本（推荐，有实时输出）

```bash
python build_exe.py
```

**特点:**
- ✅ 实时显示构建进度
- ✅ 详细的输出信息
- ✅ 自动检查依赖
- ✅ 清晰的成功/失败提示

### 方法 2: 使用批处理脚本

```bash
build.bat
```

**特点:**
- ✅ 双击即可运行
- ✅ 自动安装 PyInstaller
- ✅ 显示构建过程
- ✅ 文件大小统计

### 方法 3: 手动构建

```bash
# 1. 安装 PyInstaller
python -m pip install pyinstaller

# 2. 运行构建（会显示详细输出）
python -m PyInstaller shapecode.spec --clean
```

## ⏱️ 构建时间

- **首次构建**: 3-5 分钟
- **后续构建**: 1-2 分钟

## 📊 构建过程输出

构建时你会看到类似这样的输出：

```
========================================
Shape Code Windows Executable Build
========================================

[1/4] Checking PyInstaller...
[OK] PyInstaller ready

[2/4] Checking dependencies...
[OK] Dependencies checked

[3/4] Building executable...
This may take 3-5 minutes. Please wait...
Build output will be shown below:
======================================================================
123 INFO: PyInstaller: 5.x.x
124 INFO: Python: 3.x.x
...
[大量构建输出]
...
5432 INFO: Building EXE from EXE-00.toc completed successfully.
======================================================================

[OK] Build completed

[4/4] Verifying build result...
[OK] Executable generated: dist\ShapeCode.exe
[OK] File size: 85 MB

========================================
BUILD SUCCESSFUL!
========================================
```

## 📂 构建结果

构建成功后，你会得到：

```
dist/
  └── ShapeCode.exe    # 可执行文件（约 50-100 MB）

build/                 # 临时构建文件（可以删除）
```

## ✅ 验证构建

运行测试脚本：

```bash
test_build.bat
```

或手动测试：

```bash
# 查看版本
dist\ShapeCode.exe --version

# 查看帮助
dist\ShapeCode.exe --help

# 测试 CLI 模式
dist\ShapeCode.exe --cli examples\shapecode\basic\cube.shapecode -o test.stl

# 启动 GUI 模式
dist\ShapeCode.exe
```

## 🎯 使用可执行文件

### 启动 GUI

双击 `dist\ShapeCode.exe` 或运行：

```bash
dist\ShapeCode.exe
```

### 使用 CLI

```bash
# 编译 Shape Code 文件
dist\ShapeCode.exe --cli input.shapecode -o output.stl

# 指定格式和分辨率
dist\ShapeCode.exe --cli input.shapecode -o output.obj -f obj -r high

# 详细输出
dist\ShapeCode.exe --cli input.shapecode -o output.stl -v
```

## 📦 分发

### 分发给其他用户

1. 将 `dist\ShapeCode.exe` 复制给用户
2. 用户无需安装 Python
3. 双击即可运行

### 创建桌面快捷方式

1. 右键点击 `dist\ShapeCode.exe`
2. 选择"创建快捷方式"
3. 将快捷方式移动到桌面
4. 可选：重命名为 "Shape Code"

## 🔧 故障排除

### 问题 1: 构建过程卡住

**现象**: 构建过程长时间没有输出

**解决**:
- 等待 5-10 分钟（首次构建较慢）
- 检查是否有杀毒软件干扰
- 尝试关闭其他程序释放内存

### 问题 2: 构建失败

**现象**: 看到错误信息

**解决**:
```bash
# 1. 更新 pip
python -m pip install --upgrade pip

# 2. 重新安装 PyInstaller
python -m pip uninstall pyinstaller
python -m pip install pyinstaller

# 3. 清理后重新构建
rmdir /s /q build dist
python build_exe.py
```

### 问题 3: 可执行文件无法运行

**现象**: 双击没有反应或报错

**解决**:
```bash
# 在命令行运行查看错误信息
dist\ShapeCode.exe

# 检查是否缺少依赖
python -m pip install -r requirements.txt
```

### 问题 4: 文件太大

**现象**: 可执行文件超过 150 MB

**解决**:
- 这是正常的（包含了 Python 和所有依赖）
- 可以使用压缩软件压缩后分发
- 或使用安装程序打包

## 📝 构建日志

如果需要保存构建日志：

```bash
# 将输出保存到文件
python build_exe.py > build_log.txt 2>&1
```

## 🎓 下一步

构建成功后：

1. ✅ 测试可执行文件
2. ✅ 查看示例文件 (`examples/shapecode/`)
3. ✅ 阅读用户文档 (`README.md`)
4. ✅ 尝试自然语言生成（需要 OpenAI API Key）

## 💡 提示

- **首次构建**: 需要下载依赖，会比较慢
- **网络问题**: 如果下载失败，可以使用国内镜像
- **磁盘空间**: 确保有至少 500 MB 可用空间
- **杀毒软件**: 可能需要添加例外规则

## 📞 需要帮助？

- 查看 `BUILD_EXECUTABLE.md` - 详细构建说明
- 查看 `build_instructions.md` - 完整指南
- 查看 `EXECUTABLE_INFO.md` - 可执行文件信息

---

**准备好了吗？运行 `python build_exe.py` 开始构建！** 🚀
