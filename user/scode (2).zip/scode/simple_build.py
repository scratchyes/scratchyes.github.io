"""简化的构建脚本"""
import os
import sys

print("开始构建...")
print("当前目录:", os.getcwd())
print("Python 版本:", sys.version)

# 检查 PyInstaller
try:
    import PyInstaller
    print(f"PyInstaller 已安装: {PyInstaller.__version__}")
except ImportError:
    print("PyInstaller 未安装，请运行: pip install pyinstaller")
    sys.exit(1)

# 检查配置文件
if not os.path.exists("shapecode.spec"):
    print("错误: 未找到 shapecode.spec")
    sys.exit(1)

print("配置文件存在")
print("\n请在命令行手动运行:")
print("python -m PyInstaller shapecode.spec --clean")
print("\n这将需要 3-5 分钟时间")
