"""检测 Python 环境"""
import sys
import os

print("=" * 70)
print("Python 环境检测")
print("=" * 70)
print()

# Python 版本
print(f"Python 版本: {sys.version}")
print(f"Python 路径: {sys.executable}")
print()

# 检查关键依赖
print("检查依赖:")
print("-" * 70)

dependencies = [
    'ply',
    'trimesh',
    'numpy',
    'openai',
    'PyQt6',
    'pyinstaller'
]

installed = []
missing = []

for dep in dependencies:
    try:
        __import__(dep)
        print(f"  ✓ {dep} - 已安装")
        installed.append(dep)
    except ImportError:
        print(f"  ✗ {dep} - 未安装")
        missing.append(dep)

print()
print("=" * 70)
print(f"已安装: {len(installed)}/{len(dependencies)}")
print(f"缺失: {len(missing)}/{len(dependencies)}")

if missing:
    print()
    print("缺失的依赖:")
    for dep in missing:
        print(f"  - {dep}")
    print()
    print("安装命令:")
    print(f"  pip install {' '.join(missing)}")
else:
    print()
    print("✓ 所有依赖都已安装！")
    print("可以开始构建可执行文件了。")

print("=" * 70)
