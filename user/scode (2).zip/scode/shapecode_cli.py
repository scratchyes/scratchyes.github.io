#!/usr/bin/env python3
"""Command-line interface for Shape Code."""

import sys
import argparse
from pathlib import Path

from src.parser import Parser
from src.compiler import Compiler, CompilerOptions
from src.file_manager import FileManager


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Shape Code - A domain-specific language for 3D modeling'
    )
    
    parser.add_argument(
        'input',
        help='Input Shape Code file (.shapecode)'
    )
    
    parser.add_argument(
        '-o', '--output',
        help='Output file path (default: output.stl)',
        default='output.stl'
    )
    
    parser.add_argument(
        '-f', '--format',
        choices=['stl', 'obj'],
        help='Output format (default: stl)',
        default='stl'
    )
    
    parser.add_argument(
        '-r', '--resolution',
        choices=['low', 'medium', 'high'],
        help='Mesh resolution (default: medium)',
        default='medium'
    )
    
    parser.add_argument(
        '--no-optimize',
        action='store_true',
        help='Disable mesh optimization'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Verbose output'
    )
    
    args = parser.parse_args()
    
    # Load input file
    print(f"Loading {args.input}...")
    file_manager = FileManager()
    load_result = file_manager.load_shapecode(args.input)
    
    if load_result.is_err():
        print(f"Error loading file: {load_result.unwrap_err()}")
        return 1
    
    code = load_result.unwrap()
    
    if args.verbose:
        print(f"Loaded {len(code)} characters")
        print("\nShape Code:")
        print("-" * 60)
        print(code)
        print("-" * 60)
    
    # Parse
    print("Parsing...")
    shape_parser = Parser()
    parse_result = shape_parser.parse(code)
    
    if parse_result.is_err():
        print(f"Parse error: {parse_result.unwrap_err()}")
        return 1
    
    ast = parse_result.unwrap()
    
    if args.verbose:
        print(f"Parsed {len(ast)} statements")
    
    # Validate
    print("Validating...")
    validate_result = shape_parser.validate(ast)
    
    if validate_result.is_err():
        print(f"Validation error: {validate_result.unwrap_err()}")
        return 1
    
    if args.verbose:
        print("Validation passed")
    
    # Compile
    print("Compiling...")
    options = CompilerOptions(
        resolution=args.resolution,
        optimize=not args.no_optimize
    )
    compiler = Compiler(options)
    
    compile_result = compiler.compile(ast)
    
    if compile_result.is_err():
        print(f"Compilation error: {compile_result.unwrap_err()}")
        return 1
    
    result = compile_result.unwrap()
    
    if result.mesh is None:
        print("Error: No mesh generated")
        return 1
    
    print(f"Compilation successful!")
    print(f"  Vertices: {result.vertex_count}")
    print(f"  Faces: {result.face_count}")
    
    # Optimize if requested
    if not args.no_optimize:
        print("Optimizing mesh...")
        optimize_result = compiler.optimize_mesh(result.mesh)
        if optimize_result.is_ok():
            result.mesh = optimize_result.unwrap()
            print(f"  Optimized vertices: {len(result.mesh.vertices)}")
            print(f"  Optimized faces: {len(result.mesh.faces)}")
    
    # Export
    print(f"Exporting to {args.output}...")
    
    if args.format == 'stl':
        export_result = compiler.export_stl(result.mesh, args.output)
    else:
        export_result = compiler.export_obj(result.mesh, args.output)
    
    if export_result.is_err():
        print(f"Export error: {export_result.unwrap_err()}")
        return 1
    
    # Get file size
    output_path = Path(args.output)
    file_size = output_path.stat().st_size
    
    print(f"✓ Export successful!")
    print(f"  Output: {args.output}")
    print(f"  Size: {file_size:,} bytes ({file_size / 1024:.1f} KB)")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
