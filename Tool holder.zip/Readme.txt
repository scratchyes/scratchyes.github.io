Name: Tool holder
Designed by: Andrés Pinto


This design solution is provided by Andrés Pinto! You are welcome to download and use it! 
If you also want to contribute to the ELEGOO FDM printing community, feel free to contact us!



设计名称：Tool holder
设计者：Andrés Pinto

本设计方案由用户Andrés Pinto提供！欢迎大家下载使用！如果您也想为ELEGOO社区做出贡献，欢迎联系我们！

